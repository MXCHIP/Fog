//
//  MicoEnums.h
//  Pods
//
//  Created by WuZhengBin on 2016/7/21.
//
//

#ifndef MicoEnums_h
#define MicoEnums_h
typedef enum : NSUInteger {
    TaskTypeTimer = 0,
    TaskTypeDelayed = 1,
} TaskType;

#endif /* MicoEnums_h */
