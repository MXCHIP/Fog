//
//  Deye.h
//  Deye
//
//  Created by 黄坚 on 2017/10/24.
//  Copyright © 2017年 黄坚. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Deye.
FOUNDATION_EXPORT double DeyeVersionNumber;

//! Project version string for Deye.
FOUNDATION_EXPORT const unsigned char DeyeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Deye/PublicHeader.h>

#import "DeyeUserManager.h"
#import "DeyeMQTTManager.h"
#import "DeyeEasyLinkManager.h"
#import "DeyeDeviceManager.h"
#import "MqttInfo.h"
#import "ZBBonjourService.h"

#import "AXZWifiLinkProtocol.h"
#import "EasyLink.h"
#import "EasyLinkForAXZWifiLink.h"
#import "MXCHIPAirlink.h"

