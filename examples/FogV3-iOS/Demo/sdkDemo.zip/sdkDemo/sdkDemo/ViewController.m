//
//  ViewController.m
//  sdkDemo
//
//  Created by 黄坚 on 2017/11/24.
//  Copyright © 2017年 黄坚. All rights reserved.
//

#import "ViewController.h"
#import <FogV3/FogV3.h>
@interface ViewController ()
@property (nonatomic,strong)MqttInfo *mqttInfo;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[FogUserManager sharedInstance]loginWithName:@"" password:@"" appid:@"" extend:nil success:^(id responseObject) {
        
    } failure:^(NSError *error) {
        
    }];
    [[FogMQTTManager sharedInstance]startListenDeviceWithMqttInfo:self.mqttInfo usingSSL:NO connectHandler:^(NSError *error) {
        
    }];
    [[FogDeviceManager sharedInstance]getDeviceListWithToken:@"" success:^(id responseObject) {
        
    } failure:^(NSError *error) {
        
    }];
    [[FogEasyLinkManager sharedInstance]startEasyLinkWithPassword:@""];
    
}


@end
