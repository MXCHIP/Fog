//
//  ZBServiceBrowser.h
//  ZBNetServices
//
//  Created by wuzhengbin on 2017/3/7.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "ZBServiceDiscoveryOperation.h"
#import "ZBService.h"

NS_ASSUME_NONNULL_BEGIN

@class ZBServiceBrowser;

@protocol ZBServiceBrowserDelegate <NSObject>
- (void) serviceBrowser:(ZBServiceBrowser *)serviceBrowser didFindService:(ZBService *)service moreComing:(BOOL)moreComing;
- (void) serviceBrowser:(ZBServiceBrowser *)serviceBrowser didRemoveService:(ZBService *)service moreComing:(BOOL)moreComing;
@end

@interface ZBServiceBrowser : ZBServiceDiscoveryOperation
@property (nonatomic, weak, nullable) id<ZBServiceBrowserDelegate> delegate;

@property (nonatomic, strong, readonly) NSString *type;
@property (nonatomic, strong, readonly) NSString *domain;

- (id) initWithType:(NSString *)svcType domain:(NSString *)svcDomain;
- (ZBService *)resolverForService:(NSString *)name;
- (BOOL) resolveService:(NSString *)name delegate:(id<ZBServiceDelegate>)resolveDelegate;
/** Begins browsing for services using any interface index. */
- (BOOL) beginBrowse;
/** Begins browsing for services over Bluetooth only. */
- (BOOL) beginBrowseOverBluetoothOnly;
/** Begins browsing for services using the specified interface index. If interfaceIndex is kDNSServiceInterfaceIndexAny, P2P (i.e. Bluetooth) interfaces are only enabled if parameter includeP2P is set to YES. */
- (BOOL) beginBrowse:(uint32_t)interfaceIndex includeP2P:(BOOL)includeP2P;
/** Ends an active browse operation. */
- (void) endBrowse;
@end

NS_ASSUME_NONNULL_END
