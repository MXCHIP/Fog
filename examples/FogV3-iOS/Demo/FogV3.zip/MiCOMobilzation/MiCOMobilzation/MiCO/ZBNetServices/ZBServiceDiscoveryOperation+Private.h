//
//  ZBServiceDiscoveryOperation+Private.h
//  ZBNetServices
//
//  Created by wuzhengbin on 2017/3/7.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef struct _DNSServiceRef_t *DNSServiceRef;

NS_ASSUME_NONNULL_BEGIN

@class ZBServiceDiscoveryOperation;

@interface ZBServiceDiscoveryOperationCallbackContext : NSObject
@property (atomic, weak) ZBServiceDiscoveryOperation *operation;
@end

@interface ZBServiceDiscoveryOperation ()

@property (nonatomic, nullable, readonly) DNSServiceRef serviceRef;
@property (nonatomic, nullable, readonly) dispatch_queue_t sdDispatchQueue;
@property (nonatomic, weak, readonly) dispatch_queue_t effectiveMainDispatchQueue;

@property (nonatomic, nullable, strong) ZBServiceDiscoveryOperationCallbackContext *currentCallbackContext;

- (ZBServiceDiscoveryOperationCallbackContext *)setCurrentCallbackContextWithSelf;
- (BOOL) setServiceRef:(DNSServiceRef)serviceRef;
- (void) resetServiceRef;
- (void) dnsServiceError:(int32_t)error;
- (void) ZBDebugLog:(NSString *)format, ...;

@end

NS_ASSUME_NONNULL_END
