//
//  ZBServicePublisher.h
//  ZBNetServices
//
//  Created by wuzhengbin on 2017/3/8.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "ZBServiceDiscoveryOperation.h"

NS_ASSUME_NONNULL_BEGIN

@class ZBServicePublisher;

@protocol ZBServicePublisherDelegate <NSObject>
- (void) serviceDidPublish:(ZBServicePublisher *)servicePublisher;
- (void) serviceDidNotPublish:(ZBServicePublisher *)servicePublisher;
@end

@interface ZBServicePublisher : ZBServiceDiscoveryOperation
@property (nonatomic, weak, nullable) id<ZBServicePublisherDelegate> delegate;
@property (nonatomic, strong, readonly) NSString *name;
@property (nonatomic, strong, readonly) NSString *type;
@property (nonatomic, strong, readonly) NSString *domain;

@property (nonatomic, strong, nullable) NSData *txtData;


@end

NS_ASSUME_NONNULL_END
