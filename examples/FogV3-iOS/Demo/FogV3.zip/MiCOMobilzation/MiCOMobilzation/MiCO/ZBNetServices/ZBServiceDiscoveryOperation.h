//
//  ZBServiceDiscoveryOperation.h
//  ZBNetServices
//
//  Created by wuzhengbin on 2017/3/7.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZBServiceDiscoveryOperation : NSObject

@property (nonatomic) int32_t lastError;
@property (nonatomic, readonly) BOOL hasFailed;

@property (nonatomic, weak, readonly) dispatch_queue_t mainDispatchQueue;

@end

#pragma mark - Utility categories

@interface NSDictionary (ZBNetServices)
- (nullable NSData *) dataFromTXTRecordDictionary;
@end

@interface NSData (ZBNetServices)
- (nullable NSDictionary *) dictionaryFromTXTRecordData;
- (nullable NSString *) stringFromData;
@end

NS_ASSUME_NONNULL_END

