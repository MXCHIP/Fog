//
//  WZBFogcloudManager.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBFogcloudManager.h"

@interface WZBFogcloudManager ()
@property (nonatomic, copy) NSString *generalServer;
@end

@implementation WZBFogcloudManager
+ (instancetype)sharedManager {
    static WZBFogcloudManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[WZBFogcloudManager alloc] init];
    });
    return manager;
}

- (void)setupConfigWithHost:(NSString *)host appid:(NSString *)appid {
    [XMCenter setupConfig:^(XMConfig * _Nonnull config) {
        config.generalServer = host;
        
    }];
}

- (void)loginWithName:(NSString *)name password:(NSString *)password appid:(NSString *)appid finished:(void (^)(NSDictionary *responseObject, NSError *error))finishedBlock {
    //
    
}
@end
