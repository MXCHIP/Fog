//
//  WZBFogcloudManager.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMNetWorking.h"

@interface WZBFogcloudManager : NSObject
+ (instancetype)sharedManager;
- (void)setupConfigWithHost:(NSString *)host appid:(NSString *)appid;
- (void)loginWithName:(NSString *)name password:(NSString *)password appid:(NSString *)appid finished:(void (^)(NSDictionary *responseObject, NSError *error))finishedBlock;
@end
