//
//  WZBMineViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBMineViewController.h"
#import "UIImage+WZBAdd.h"
#import "SIAlertView.h"
#import "XMNetworking.h"
#import "WZBAppUtils.h"
#import "WZBUserObject.h"
#import "NSFileManager+WZBPaths.h"

static NSInteger const SECTION_AVATAR = 0;
static NSInteger const SECTION_FEED_AND_VERSION = 1;
static NSInteger const SECTION_LOGOUT = 2;

static NSInteger const ROW_FEEDBACK = 0;
static NSInteger const ROW_VERSION = 1;

static CGFloat const AVATAR_SIZE = 50;
static CGFloat const CELL_PADDING = 15;

@interface WZBMineViewController () <UITableViewDataSource, UITableViewDelegate>
@property(nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) WZBUserObject *userObject;
@end

@implementation WZBMineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.tableView];
    
    NSString *userPath = [[NSFileManager wzb_documentsPath] stringByAppendingPathComponent:@"user.archive"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:userPath]) {
        WZBUserObject *object = [NSKeyedUnarchiver unarchiveObjectWithFile:userPath];
        self.userObject = object;
        [self.tableView reloadData];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        
        _tableView.estimatedRowHeight = 100;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    }
    return _tableView;
}

#pragma mark - UITableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case SECTION_AVATAR:
            return 1;
        case SECTION_FEED_AND_VERSION:
            return 2;
        case SECTION_LOGOUT:
            return 1;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    
    if (section == SECTION_LOGOUT) {
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.text = @"退出登录";
    }
    
    if (section == SECTION_FEED_AND_VERSION) {
        if (row == ROW_VERSION) {
            cell.textLabel.text = @"版本1.0";
        } else if (row == ROW_FEEDBACK) {
            cell.textLabel.text = @"反馈";
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    if (section == SECTION_AVATAR) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.textLabel.text = @"Fog总动员";
        cell.detailTextLabel.text = [NSString stringWithFormat:@"帐号: fogcloud"];
        cell.imageView.image = [[UIImage wzb_imageWithColor:[UIColor redColor]] wzb_imageByResizeToSize:CGSizeMake(AVATAR_SIZE, AVATAR_SIZE)];
        cell.imageView.clipsToBounds = YES;
        cell.imageView.layer.cornerRadius = AVATAR_SIZE * 0.5;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == SECTION_AVATAR) {
        return AVATAR_SIZE + CELL_PADDING * 2;
    }
    return 44.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == SECTION_AVATAR) {
        return;
    } else if (indexPath.section == SECTION_FEED_AND_VERSION) {
        if (indexPath.row == ROW_FEEDBACK) {
            SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:nil andMessage:@"若您有任何好的建议\n欢迎您到 www.mico.io 反馈"];
            alertView.transitionStyle = SIAlertViewTransitionStyleDropDown;
            [alertView addButtonWithTitle:@"OK" type:SIAlertViewButtonTypeCancel handler:nil];
            [alertView show];
        }
    } else if (indexPath.section == SECTION_LOGOUT) {
        SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:@"警告" andMessage:@"您真的要退出登录吗"];
        alertView.transitionStyle = SIAlertViewTransitionStyleBounce;
        [alertView addButtonWithTitle:@"取消" type:SIAlertViewButtonTypeCancel handler:nil];
        [alertView addButtonWithTitle:@"确定" type:SIAlertViewButtonTypeDestructive handler:^(SIAlertView *alertView) {
            [[WZBAppUtils sharedUtil] removeToken];
        }];
        [alertView show];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
