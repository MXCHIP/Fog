//
//  WZBAddDeviceViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBAddDeviceViewController.h"
#import "PureLayout.h"
#import "WZBConfigureView.h"
#import "EasyLink.h"
#import "ZBServiceBrowser.h"
#import "UIImage+WZBAdd.h"
#import "NSString+WZBAdd.h"
#import "UIButton+WZBBackgroundColor.h"
#import "Chameleon.h"
#import "UIView+WZBAddCorner.h"
#import "UIButton+WZBTouchAreaInsets.h"
#import "NSArray+WZBBlock.h"
#import "NSDictionary+WZBSafeAccess.h"
#import "GCDAsyncSocket.h"
#import "NSArray+WZBBlock.h"
#import "WZBAppUtils.h"
#import "SVProgressHUD.h"
#import "ZBBonjourService.h"
@import XMNetworking;

@interface WZBAddDeviceViewController () <ZBBonjourServiceDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) WZBConfigureView *configureView;
@property(nonatomic, strong) ZBServiceBrowser *browser;
@property (nonatomic, strong) UIBarButtonItem *rightBarButtonItem;


@property (nonatomic,strong)NSTimer *myTimer;
@property (nonatomic,strong)NSMutableArray *devices;

@property (nonatomic,assign)NSInteger value;
@end

@implementation WZBAddDeviceViewController {
    NSMutableArray *browseResult;
    NSMutableArray *filteredResult;
    EASYLINK *easylink_config;
    BOOL showAllDevices;
}
-(NSMutableArray *)devices
{
    if (!_devices) {
        _devices=[NSMutableArray array];
    }
    return _devices;
}

- (void)rightBarButtonItemDidClicked:(UIBarButtonItem *)item {
    showAllDevices = !showAllDevices;
    [item setTitle:showAllDevices ? @"过滤" : @"显示全部"];
    [self.tableView reloadData];
}

- (UIBarButtonItem *)rightBarButtonItem {
    if (!_rightBarButtonItem) {
        _rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"过滤" style:UIBarButtonItemStylePlain target:self action:@selector(rightBarButtonItemDidClicked:)];
    }
    return _rightBarButtonItem;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    showAllDevices = YES;
    
    //[self.navigationItem setRightBarButtonItem:self.rightBarButtonItem];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    browseResult = [NSMutableArray array];
    filteredResult = [NSMutableArray array];
    
    WZBConfigureView *configureView = [WZBConfigureView newAutoLayoutView];
    [self.view addSubview:configureView];
    
    self.configureView = configureView;
    [configureView autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.view];
    [configureView autoPinEdgeToSuperviewEdge:ALEdgeLeading];
    //    [configureView autoSetDimension:ALDimensionHeight toSize:200.0];
    [configureView autoPinToTopLayoutGuideOfViewController:self withInset:0];

    self.configureView.ssidTextField.text = [EASYLINK ssidForConnectedNetwork];
    [self.configureView.startButton addTarget:self action:@selector(startButtonDidClicked:) forControlEvents:UIControlEventTouchUpInside];

    
    [self searchDevice];
}

#pragma mark - TIMER

-(NSTimer *)myTimer {
    if (!_myTimer) {
        _myTimer =  [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(getProgress) userInfo:nil repeats:YES];
        //每1秒运行一次。
    }
    return _myTimer;
}
//取消定时器
-(void)removeTimer {
    [_myTimer invalidate];
    _myTimer=nil;
}
//开启定时器
-(void)startTimer {
    [self.myTimer setFireDate:[NSDate distantPast]];
}


-(void)getProgress
{
    self.value++;
    
    if (self.value==60) {
        [SVProgressHUD dismiss];
        [self removeTimer];
        [[ZBBonjourService sharedInstance] stopSearchDevice];
        if (self.devices.count>0) {
            
            [self bindDevice];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshDeviceList" object:nil];
            [self.navigationController popViewControllerAnimated:YES];
        }else
        {
            [SVProgressHUD showErrorWithStatus:@"配网失败"];
            [SVProgressHUD dismissWithDelay:0.5];
            [easylink_config stopTransmitting];
        }
        
        
    }
}
-(void)bindDevice
{
    NSDictionary *dic = self.devices.firstObject;
    NSDictionary *recordData = dic[@"RecordData"];
    NSString *deviceId=[recordData objectForKey:@"fog_v3_deviceid"];
    //NSString *deviceId=@"a46ddd7465ed11e7a554fa163e876164";
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api=@"/v3/enduser/bindDevice/";
        request.headers=@{@"Authorization":[NSString stringWithFormat:@"JWT %@", [WZBAppUtils sharedUtil].token]};
        request.parameters = @{@"deviceid":deviceId};
        
    } onSuccess:^(id  _Nullable responseObject) {
        NSInteger code=(NSInteger)responseObject[@"meta"][@"code"];
        if (code==0) {
            [SVProgressHUD showSuccessWithStatus:@"绑定成功"];
            [SVProgressHUD dismissWithDelay:0.5];
        }else
        {
            [SVProgressHUD showErrorWithStatus:@"绑定失败"];
            [SVProgressHUD dismissWithDelay:0.5];
        }
        
    } onFailure:^(NSError * _Nullable error) {
        
    }];
}


-(void)searchDevice
{
    [[ZBBonjourService sharedInstance] stopSearchDevice];
    [ZBBonjourService sharedInstance].delegate=self;
    [[ZBBonjourService sharedInstance] startSearchDevice];
}
#pragma  mark - ZBBonjourService Delegate
-(void)bonjourService:(ZBBonjourService *)service didReturnDevicesArray:(NSArray *)array
{
    self.devices=[NSMutableArray arrayWithArray:array];
    
    NSLog(@"---hj %@",self.devices);
    [self.devices enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *dic = obj;
        NSDictionary *recordData = dic[@"RecordData"];
        //[recordData property];
        NSString *isNeedStopEasylink = [recordData objectForKey:@"fog_v3_is_need_stop_easylink"];
        
        if ([isNeedStopEasylink isEqualToString:@"true"]) {
            [self.devices removeObject:obj];
        }
        
    }];
    
    
}



- (void)startButtonDidClicked:(id)sender {
    if (easylink_config) {
        [easylink_config unInit];
    }
    NSData *ssidData = [EASYLINK ssidDataForConnectedNetwork];
    
    NSMutableDictionary *innerParams = [NSMutableDictionary dictionaryWithCapacity:5];
    [innerParams setObject:ssidData forKey:KEY_SSID];
    [innerParams setObject:self.configureView.passwordTextField.text forKey:KEY_PASSWORD];
    [innerParams setObject:[NSNumber numberWithBool:YES] forKey:KEY_DHCP];
    
    easylink_config = [[EASYLINK alloc] init];
    [easylink_config prepareEasyLink:innerParams info:nil mode:EASYLINK_V2_PLUS];
    [easylink_config transmitSettings];
    [self startTimer];
    [SVProgressHUD showWithStatus:@"配网中"];
    [SVProgressHUD setDefaultMaskType:SVProgressHUDMaskTypeBlack];
}

@end
