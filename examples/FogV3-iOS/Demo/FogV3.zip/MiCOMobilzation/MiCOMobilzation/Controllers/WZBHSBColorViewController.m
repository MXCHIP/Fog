//
//  WZBHSBColorViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/20.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBHSBColorViewController.h"
#import "RLColorPicker.h"
#import "UIView+WZBFrame.h"
#import "WZBAppUtils.h"
#import "NSDictionary+WZBJSONString.h"
@import PureLayout;
@import ChameleonFramework;
@import MQTTClient;
@import XMNetworking;

@interface WZBHSBColorViewController () <RLColorPickerDelegate>
@property (nonatomic, strong) RLColorPicker *colorPicker;
@property (nonatomic, strong) WZBDeviceObject *object;
@property (nonatomic, strong) UIButton *placeholderButton;
@end

@implementation WZBHSBColorViewController

- (instancetype)initWithDeviceObject:(WZBDeviceObject *)object {
    if (self = [super init]) {
        self.object = object;
    }
    return self;
}

- (void)handleButtonEvent:(UIButton *)button {
//    self getHSBAValueByColor:button.backgroundColor
    NSDictionary *dic = [self getHSBAValueByColor:button.backgroundColor];
    NSDictionary *commandDic = @{@"command_id":@(1),
                                 @"rgb_led_h":@([dic[@"H"] integerValue]*360),
                                 @"rgb_led_s":@([dic[@"S"] integerValue]*100),
                                 @"rgb_led_b":@([dic[@"B"] integerValue]*100)};
    NSLog(@"现在发的命令是啥呢:%@", commandDic);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    self.colorPicker = [[RLColorPicker alloc] initWithColor:[UIColor redColor] withFrame:CGRectZero];
    self.colorPicker.delegate = self;
    [self.view addSubview:self.colorPicker];

    self.placeholderButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 200, 200)];
    self.placeholderButton.backgroundColor = [UIColor redColor];
    self.placeholderButton.layer.masksToBounds = YES;
    self.placeholderButton.layer.cornerRadius = 200/2;
    self.placeholderButton.wzb_centerX = self.view.wzb_centerX;
    self.placeholderButton.wzb_top = 64+20;
    [self.view addSubview:self.placeholderButton];
    [self.placeholderButton addTarget:self action:@selector(handleButtonEvent:) forControlEvents:UIControlEventTouchUpInside];
    
    self.colorPicker = [[RLColorPicker alloc] initWithColor:self.placeholderButton.backgroundColor withFrame:CGRectMake(20, self.placeholderButton.wzb_bottom + 30, self.view.wzb_width-40, 180)];
    self.colorPicker.delegate = self;
    [self.view addSubview:self.colorPicker];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getPickerColor:(UIColor *)color {
    self.placeholderButton.backgroundColor = color;
    NSDictionary *dic = [self getHSBAValueByColor:color];
    
    NSDictionary *commandDic = @{@"command_id":@(1),
                             @"rgb_led_h":@([dic[@"H"] floatValue]*360),
                             @"rgb_led_s":@([dic[@"S"] floatValue]*100),
                             @"rgb_led_b":@([dic[@"B"] floatValue]*100)};
    
    NSDictionary *params = @{@"deviceid":self.object.device_id,
                             @"devicepw":self.object.device_pw,
                             @"format":@"json",
                             @"payload":[commandDic wzb_JSONString]};
    
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"enduser/sendCommandAdv/";
        request.httpMethod = kXMHTTPMethodPOST;
        request.parameters = params;
        request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
    } onSuccess:^(id  _Nullable responseObject) {
        NSLog(@"发送命令成功:%@", responseObject);
    } onFailure:^(NSError * _Nullable error) {
        NSLog(@"发送命令失败:%@", error.localizedDescription);
    }];

}

- (NSDictionary *)getHSBAValueByColor:(UIColor *)originColor
{
    CGFloat h=0, s=0, b=0, a=0;
    if ([originColor respondsToSelector:@selector(getHue:saturation:brightness:alpha:)]) {
        [originColor getHue:&h saturation:&s brightness:&b alpha:&a];
    }
    
    return @{@"H":@(h),
             @"S":@(s),
             @"B":@(b),
             @"A":@(a)};
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
