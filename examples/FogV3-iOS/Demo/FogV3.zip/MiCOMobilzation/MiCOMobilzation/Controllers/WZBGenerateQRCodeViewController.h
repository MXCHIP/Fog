//
//  WZBGenerateQRCodeViewController.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/20.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WZBDeviceObject.h"
@interface WZBGenerateQRCodeViewController : UIViewController
- (instancetype)initWithObject:(WZBDeviceObject *)object;
@end
