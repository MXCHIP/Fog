//
//  WZBRegisterViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBRegisterViewController.h"
#import "PureLayout.h"
#import "MiCOMobilzation-Bridging-Header.h"
@import TextFieldEffects;
@import SVProgressHUD;
@import XMNetworking;
@import SAMKeychain;
#import "WZBAppUtils.h"
#import "UIButton+WZBBackgroundColor.h"
#import "UIView+WZBAddCorner.h"
#import "UIColor+WZBAdd.h"
#import "UIButton+WZBCountDown.h"
#import "WZBUserObject.h"
#import "NSFileManager+WZBPaths.h"

@interface WZBRegisterViewController ()
@property (nonatomic, strong) HoshiTextField *loginPhoneTextField;
@property (nonatomic, strong) HoshiTextField *loginCodeTextField;
@property (nonatomic, strong) HoshiTextField *passwordTextField;
@property (nonatomic, strong) HoshiTextField *confirmTextField;
@property (nonatomic, strong) UIButton *registerButton;
@property (nonatomic, strong) UIButton *fetchCodeButton;
@end

@implementation WZBRegisterViewController

- (void)setupPhoneField {
    self.loginPhoneTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_loginPhoneTextField];
    
    [_loginPhoneTextField autoPinToTopLayoutGuideOfViewController:self withInset:10.0f];
    [_loginPhoneTextField autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10.0f];
    [_loginPhoneTextField autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10.0f];
    [_loginPhoneTextField autoSetDimension:ALDimensionHeight toSize:50.0f];
    
    _loginPhoneTextField.placeholder = @"请输入手机号";
    _loginPhoneTextField.borderInactiveColor = [UIColor lightGrayColor];
    _loginPhoneTextField.borderActiveColor = [UIColor wzb_colorWithHexString:@"00c1e1"];
    
    _loginPhoneTextField.keyboardType = UIKeyboardTypePhonePad;
}

- (void)setupCodeField {
    self.loginCodeTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_loginCodeTextField];
    
    [_loginCodeTextField autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_loginCodeTextField autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_loginCodeTextField autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.loginPhoneTextField];
    [_loginCodeTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginPhoneTextField withOffset:5.0f];
    
    _loginCodeTextField.placeholder = @"请输入验证码";
    _loginCodeTextField.borderInactiveColor = _loginPhoneTextField.borderInactiveColor;
    _loginCodeTextField.borderActiveColor = _loginPhoneTextField.borderActiveColor;
    
    _loginCodeTextField.keyboardType = UIKeyboardTypePhonePad;
}

- (void)setupPasswordField {
    self.passwordTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_passwordTextField];
    
    [_passwordTextField autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_passwordTextField autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_passwordTextField autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.loginPhoneTextField];
    [_passwordTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginCodeTextField withOffset:5.0f];
    
    _passwordTextField.placeholder = @"请输入密码";
    _passwordTextField.borderInactiveColor = _loginPhoneTextField.borderInactiveColor;
    _passwordTextField.borderActiveColor = _loginPhoneTextField.borderActiveColor;
    
    _passwordTextField.keyboardType = UIKeyboardTypeDefault;
    _passwordTextField.secureTextEntry = YES;
}

- (void)setupConfirmField {
    self.confirmTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_confirmTextField];
    
    [_confirmTextField autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_confirmTextField autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_confirmTextField autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.loginPhoneTextField];
    [_confirmTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passwordTextField withOffset:5.0f];
    
    _confirmTextField.placeholder = @"请再输入一次密码";
    _confirmTextField.borderInactiveColor = _loginPhoneTextField.borderInactiveColor;
    _confirmTextField.borderActiveColor = _loginPhoneTextField.borderActiveColor;
    
    _confirmTextField.keyboardType = UIKeyboardTypeDefault;
    _confirmTextField.secureTextEntry = YES;
}

- (void)setupRegisterButton {
    self.registerButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.registerButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_registerButton];
    
    [_registerButton wzb_setBackgroundColor:[UIColor wzb_colorWithHexString:@"00c1e1"]
                               forState:UIControlStateNormal];
    [_registerButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_registerButton autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_registerButton autoSetDimension:ALDimensionHeight toSize:44.0f];
    [_registerButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:_confirmTextField withOffset:40.0f];
    [_registerButton setTitle:@"注册" forState:UIControlStateNormal];
    [self.registerButton addTarget:self action:@selector(handleRegisterButtonEvent:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setupFetchCodeButton {
    self.fetchCodeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.fetchCodeButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.loginCodeTextField addSubview:_fetchCodeButton];
    
    [self.fetchCodeButton autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.fetchCodeButton wzb_setBackgroundColor:[UIColor wzb_colorWithHexString:@"00c1e1"] forState:UIControlStateNormal];
    [self.fetchCodeButton autoPinEdgeToSuperviewEdge:ALEdgeTrailing];
    [self.fetchCodeButton autoSetDimension:ALDimensionHeight toSize:25];
    [self.fetchCodeButton autoSetDimension:ALDimensionWidth toSize:80 relation:NSLayoutRelationGreaterThanOrEqual];
    [self.fetchCodeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
    [self.fetchCodeButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [self.fetchCodeButton addTarget:self action:@selector(handleFetchCodeEvent:) forControlEvents:UIControlEventTouchUpInside];
}
#pragma mark - Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:1.00 green:0.00 blue:0.38 alpha:1.00]];
    
    self.title = @"注册";
    
    [self setupPhoneField];
    [self setupCodeField];
    [self setupPasswordField];
    [self setupConfirmField];
    [self setupRegisterButton];
    [self setupFetchCodeButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [_fetchCodeButton wzb_addCustomCornerWithSize:CGSizeMake(5*2, 5*2)];
    [_registerButton wzb_addCustomCornerWithSize:CGSizeMake(5*2*2, 5*2*2)];
}


#pragma mark - Selectors
- (void)handleRegisterButtonEvent:(UIButton *)button {
    // 链式请求
    [XMCenter sendChainRequest:^(XMChainRequest * _Nonnull chainRequest) {
        [[chainRequest onFirst:^(XMRequest * _Nonnull request) {
            request.api = @"/v3/enduser/checkVerCode/";
            request.parameters = @{@"appid":[[WZBAppUtils sharedUtil] appid],
                                   @"loginname":self.loginPhoneTextField.text,
                                   @"vercode":self.loginCodeTextField.text};
        }] onNext:^(XMRequest * _Nonnull request, id  _Nullable responseObject, BOOL * _Nonnull isSent) {
            NSDictionary *params = responseObject;
            [[WZBAppUtils sharedUtil] saveToken:responseObject[@"data"][@"token"]];
            [[WZBAppUtils sharedUtil] saveClientId:responseObject[@"data"][@"clientid"]];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshDeviceList" object:nil];
            if (params.count > 0) {
                request.api = @"/v3/enduser/resetPassword/";
                request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
                request.parameters = @{@"password1": self.passwordTextField.text,
                                       @"password2": self.confirmTextField.text};
            } else {
                *isSent = NO;
            }
        }];
    } onSuccess:^(NSArray * _Nonnull responseObjects) {
        /**
         {
            data =         {
            };
            meta =         {
                code = 0;
                message = "Update password successfully.";
            };
         */
        NSDictionary *dict=responseObjects.firstObject;
        NSInteger code=[[[dict objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        
        if (code==0) {
        
        NSLog(@"On Success: %@", responseObjects);
        [SAMKeychain setPassword:self.passwordTextField.text
                      forService:@"com.mxchip.mico.app.user"
                         account:@"user"];
            [SVProgressHUD showSuccessWithStatus:@"注册成功"];
            [SVProgressHUD dismissWithDelay:1.0];
//            [self dismissViewControllerAnimated:YES completion:^{
//                [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
//                    request.httpMethod = kXMHTTPMethodGET;
//                    request.api = @"enduser/getUserInfo/";
//                    request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
//                } onFinished:^(id  _Nullable responseObject, NSError * _Nullable error) {
//                    NSDictionary *data = [(NSDictionary *)responseObject objectForKey:@"data"];
//                    WZBUserObject *user = [WZBUserObject mj_objectWithKeyValues:data];
//                    NSString *userPath = [[NSFileManager wzb_documentsPath] stringByAppendingPathComponent:@"user.archive"];
//                    BOOL success = [NSKeyedArchiver archiveRootObject:user toFile:userPath];
//                    if (!success) {
//                        NSLog(@"保存失败");
//                    } else {
//                        NSLog(@"保存成功");
//                    }
//                    
//                }];
//           }];
            
        }
    } onFailure:^(NSArray * _Nonnull errors) {
        NSLog(@"On Failure: %@", errors);
    } onFinished:^(NSArray * _Nullable responseObjects, NSArray * _Nullable errors) {
        
    }];
}

- (void)handleFetchCodeEvent:(UIButton *)button {
    if (self.loginPhoneTextField.text.length == 0) {
        [SVProgressHUD showErrorWithStatus:@"请输入手机号码"];
        return;
    }
    
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"/v3/enduser/getVerCode/";
        request.parameters = @{@"appid":[[WZBAppUtils sharedUtil] appid],
                               @"loginname":self.loginPhoneTextField.text};
    } onFinished:^(id  _Nullable responseObject, NSError * _Nullable error) {
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        
        if (code!=0) {
            [SVProgressHUD showErrorWithStatus:error.localizedDescription];
        } else {
            /**
             {
                data =     {
                };
                meta =     {
                    code = 0;
                    message = "Send message to phone successfully.";
                };
             }
             */
            [SVProgressHUD showSuccessWithStatus:@"获取验证码成功"];
            NSLog(@"[INFO] - /enduser/getVercode/ - \n %@", responseObject);
            [button wzb_startTime:59 title:@"获取验证码" waitingTitle:@" s"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.loginCodeTextField becomeFirstResponder];
            });
        }
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
