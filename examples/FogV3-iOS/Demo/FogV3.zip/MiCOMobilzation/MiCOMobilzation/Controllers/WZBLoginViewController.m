//
//  WZBLoginViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBLoginViewController.h"
#import "PureLayout.h"
#import "MiCOMobilzation-Bridging-Header.h"
@import TextFieldEffects;
#import "UIButton+WZBBackgroundColor.h"
#import "UIView+WZBAddCorner.h"
#import "UIColor+WZBAdd.h"
#import "WZBRegisterViewController.h"
#import "XMNetworking.h"
#import "SVProgressHUD.h"
#import "WZBAppUtils.h"
#import "WZBUserObject.h"
#import "NSFileManager+WZBPaths.h"
@import SAMKeychain;

@interface WZBLoginViewController ()
@property (nonatomic, strong) UIImageView *logoImageView;
@property (nonatomic, strong) HoshiTextField *loginPhoneTextField;
@property (nonatomic, strong) HoshiTextField *loginPasswordTextField;
@property (nonatomic, strong) UIButton *loginButton;
@property (nonatomic, strong) UIButton *registerButton;
@property (nonatomic, strong) UIButton *forgetPwButton;
@end

@implementation WZBLoginViewController

- (void)setupPhoneField {
    self.loginPhoneTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_loginPhoneTextField];
    
    [_loginPhoneTextField autoPinToTopLayoutGuideOfViewController:self withInset:10.0f];
    [_loginPhoneTextField autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10.0f];
    [_loginPhoneTextField autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10.0f];
    [_loginPhoneTextField autoSetDimension:ALDimensionHeight toSize:50.0f];
    
    _loginPhoneTextField.placeholder = @"请输入手机号";
    _loginPhoneTextField.borderInactiveColor = [UIColor lightGrayColor];
    _loginPhoneTextField.borderActiveColor = [UIColor wzb_colorWithHexString:@"00c1e1"];
    
    _loginPhoneTextField.keyboardType = UIKeyboardTypePhonePad;
}

- (void)setupPasswordField {
    self.loginPasswordTextField = [HoshiTextField newAutoLayoutView];
    [self.view addSubview:_loginPasswordTextField];
    
    [_loginPasswordTextField autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_loginPasswordTextField autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_loginPasswordTextField autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.loginPhoneTextField];
    [_loginPasswordTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginPhoneTextField withOffset:5.0f];
    
    _loginPasswordTextField.placeholder = @"请输入密码";
    _loginPasswordTextField.borderInactiveColor = _loginPhoneTextField.borderInactiveColor;
    _loginPasswordTextField.borderActiveColor = _loginPhoneTextField.borderActiveColor;
    
    _loginPasswordTextField.keyboardType = UIKeyboardTypeDefault;
    _loginPasswordTextField.secureTextEntry = YES;
}

- (void)setupLoginButton {
    self.loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.loginButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_loginButton];
    
    [_loginButton wzb_setBackgroundColor:[UIColor wzb_colorWithHexString:@"00c1e1"]
                               forState:UIControlStateNormal];
    [_loginButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginPhoneTextField];
    [_loginButton autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginPhoneTextField];
    [_loginButton autoSetDimension:ALDimensionHeight toSize:44.0f];
    [_loginButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginPasswordTextField withOffset:40.0f];
    [_loginButton setTitle:@"登录" forState:UIControlStateNormal];
    
    [_loginButton addTarget:self action:@selector(handleLoginButtonEvent:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setupRegisterButton {
    self.registerButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.view addSubview:_registerButton];
    
    [_registerButton autoPinEdge:ALEdgeTrailing toEdge:ALEdgeTrailing ofView:self.loginButton withOffset:-10.0f];
    [_registerButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginButton withOffset:10.0f];
    
    [_registerButton setTitle:@"新用户注册" forState:UIControlStateNormal];
    [_registerButton setTintColor:[UIColor wzb_colorWithHexString:@"00c1e1"]];
    
    [_registerButton addTarget:self action:@selector(registerButtonDidClicked:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)setupPasswordButton {
    self.forgetPwButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.view addSubview:_forgetPwButton];
    
    [_forgetPwButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.loginButton withOffset:10.0f];
    [_forgetPwButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.loginButton withOffset:10.0f];
    [_forgetPwButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
    
    [_forgetPwButton setTintColor:[UIColor wzb_colorWithHexString:@"00c1e1"]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"登录";
    
    [self setupPhoneField];
    [self setupPasswordField];
    [self setupLoginButton];
    [self setupRegisterButton];
    [self setupPasswordButton];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)registerButtonDidClicked:(id)sender {
    WZBRegisterViewController *vc = [[WZBRegisterViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)handleLoginButtonEvent:(UIButton *)button {
    [SVProgressHUD show];
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"/v3/enduser/login/";
        request.parameters = @{@"appid":[[WZBAppUtils sharedUtil] appid],
                               @"loginname":self.loginPhoneTextField.text,
                               @"password":self.loginPasswordTextField.text};
    } onSuccess:^(id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
            NSDictionary *dic = (NSDictionary *)responseObject;
            [[WZBAppUtils sharedUtil] saveToken:dic[@"data"][@"token"]];
            [[WZBAppUtils sharedUtil] saveClientId:dic[@"data"][@"clientid"]];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshDeviceList" object:nil];
            
            // 保存密码
            [SAMKeychain setPassword:self.loginPasswordTextField.text
                          forService:@"com.mxchip.mico.app.user"
                             account:@"user"];
            [self dismissViewControllerAnimated:YES completion:nil];
        }else
        {
            [SVProgressHUD showErrorWithStatus:@"账号或密码错误"];
            [SVProgressHUD dismissWithDelay:1.0];
        }
        
      /*
        dispatch_async(dispatch_get_main_queue(), ^{
            [self dismissViewControllerAnimated:YES completion:^{
                // 保存用户信息
                [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
                    request.httpMethod = kXMHTTPMethodGET;
                    request.api = @"enduser/getUserInfo/";
                    request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
                } onFinished:^(id  _Nullable responseObject, NSError * _Nullable error) {
                    NSDictionary *data = [(NSDictionary *)responseObject objectForKey:@"data"];
                    WZBUserObject *user = [WZBUserObject mj_objectWithKeyValues:data];
                    NSString *userPath = [[NSFileManager wzb_documentsPath] stringByAppendingPathComponent:@"user.archive"];
                    BOOL success = [NSKeyedArchiver archiveRootObject:user toFile:userPath];
                    if (!success) {
                        NSLog(@"保存失败");
                    } else {
                        NSLog(@"保存成功");
                    }
                }];
            }];
        });*/
    } onFailure:^(NSError * _Nullable error) {
        [SVProgressHUD showErrorWithStatus:error.localizedDescription];
        NSLog(@"%@", error.localizedDescription);
    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [_loginButton wzb_addCustomCornerWithSize:CGSizeMake(10*2, 10*2)];
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleDefault;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
