//
//  WZBDevicesViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBDevicesViewController.h"
#import "UIImage+WZBAdd.h"
#import "WZBDeviceTableViewCell.h"
#import "MJRefresh.h"
#import "WZBDeviceDetailViewController.h"
#import "WZBQRCodeShareViewController.h"
#import "WZBAuthManageViewController.h"
#import "XMNetworking.h"
#import "WZBAppUtils.h"
#import "SVProgressHUD.h"
#import "WZBDeviceObject.h"
#import "SIAlertView.h"
#import "Chameleon.h"
#import "WZBGrantListViewController.h"
#import "WZBAddDeviceViewController.h"
#import "WZBGenerateQRCodeViewController.h"
#import "QRCodeVC.h"
#import "NSString+WZBAdd.h"

static NSString * const cellIdentifier = @"cell";

@interface WZBDevicesViewController () <UITableViewDataSource, UITableViewDelegate, MGSwipeTableCellDelegate, QRCodeVCDelegate>
@property(nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *deviceArray;
@end

@implementation WZBDevicesViewController {
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        
        _tableView.estimatedRowHeight = 100;
        _tableView.tableFooterView = [UIView new];
        _tableView.rowHeight = UITableViewAutomaticDimension;
        [_tableView registerClass:[WZBDeviceTableViewCell class] forCellReuseIdentifier:cellIdentifier];
    }
    return _tableView;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    
    
    self.deviceArray = [NSMutableArray array];
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(refresh)];
    [self.tableView setMj_header:header];
    [header beginRefreshing];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh) name:@"refreshDeviceList" object:nil];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"add_blue_128"] wzb_imageByResizeToSize:CGSizeMake(24, 24)] style:UIBarButtonItemStylePlain target:self action:@selector(rightBarButtonItemDidClicked:)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"scan_blue_128"] wzb_imageByResizeToSize:CGSizeMake(24, 24)] style:UIBarButtonItemStylePlain target:self action:@selector(leftBarButtonItemDidClicked:)];
}

- (void)refresh {

    [self.deviceArray removeAllObjects];
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"/v3/enduser/deviceList/";
        request.httpMethod = kXMHTTPMethodGET;
        request.headers = @{@"Authorization":[NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
    } onSuccess:^(id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
        NSArray *data = dic[@"data"];
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
        self.deviceArray = [WZBDeviceObject mj_objectArrayWithKeyValuesArray:data];
        [self.tableView.mj_header endRefreshing];
        [self.tableView reloadData];
        }
        
    } onFailure:^(NSError * _Nullable error) {
        
    }];
}

- (void)leftBarButtonItemDidClicked:(UIBarButtonItem *)item {
    QRCodeVC *qrVC = [[QRCodeVC alloc] init];
    qrVC.delegate = self;
    qrVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:qrVC animated:YES];
}

- (void)rightBarButtonItemDidClicked:(UIBarButtonItem *)item {
    WZBAddDeviceViewController *vc = [[WZBAddDeviceViewController alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.deviceArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WZBDeviceObject *object = [self.deviceArray objectAtIndex:indexPath.row];
    WZBDeviceTableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.delegate = self;
//    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.rightSwipeSettings.transition = MGSwipeTransitionBorder;
    [cell setRightButtons:[self rightButtons]];
    cell.object = object;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    WZBDeviceObject *object = [self objectInCell:[tableView cellForRowAtIndexPath:indexPath]];
    if (object.online == NO) {
        [SVProgressHUD showErrorWithStatus:@"设备不在线"];
        return;
    }
    WZBDeviceDetailViewController *vc = [[WZBDeviceDetailViewController alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    vc.title = @"设备详情";
    vc.deviceObject = object;
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 66.0f;
}

#pragma mark - RightButtons
- (NSArray *)rightButtons {
    NSMutableArray *rightButtonsArray = [NSMutableArray array];
    [rightButtonsArray addObject:[self deleteDeviceButton]];
    [rightButtonsArray addObject:[self grantListButton]];
    [rightButtonsArray addObject:[self shareDeviceButton]];
    
    [rightButtonsArray addObject:[self editMemoButton]];
    return rightButtonsArray;
}

- (MGSwipeButton *)shareDeviceButton {
    return [MGSwipeButton buttonWithTitle:@"分享\n设备" icon:nil backgroundColor:[UIColor flatGreenColor] callback:^BOOL(MGSwipeTableCell * _Nonnull cell) {
        
        
        
        WZBDeviceObject *object = [self objectInCell:cell];
        WZBGenerateQRCodeViewController *vc = [[WZBGenerateQRCodeViewController alloc] initWithObject:object];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
        return YES;
    }];
}

- (MGSwipeButton *)editMemoButton {
    return [MGSwipeButton buttonWithTitle:@"修改\n备注" icon:nil backgroundColor:[UIColor flatBlueColor] callback:^BOOL(MGSwipeTableCell * _Nonnull cell) {
        
        WZBDeviceObject *object = [self objectInCell:cell];
        
        UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:@"修改备注" preferredStyle:UIAlertControllerStyleAlert];
        [ac addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            
        }];
        [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [ac addAction:[UIAlertAction actionWithTitle:@"确定修改" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            UITextField *tf = [[ac textFields] firstObject];
            [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
                request.api = @"/v3/enduser/updateDeviceAlias/";
                request.parameters = @{@"deviceid":object.device_id,
                                       @"alias": tf.text};
                request.httpMethod = kXMHTTPMethodPUT;
                request.headers = @{@"Authorization":[NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
            } onSuccess:^(id  _Nullable responseObject) {
                NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
                if (code==0) {
                [cell hideSwipeAnimated:YES];
                [self.tableView.mj_header beginRefreshing];
                }
                
            } onFailure:^(NSError * _Nullable error) {
                NSLog(@"修改备注失败了: %@", error.localizedDescription);
            }];
            
        }]];
        [self presentViewController:ac animated:YES completion:nil];
        
        return NO;
    }];
}

- (MGSwipeButton *)grantListButton {
    return [MGSwipeButton buttonWithTitle:@"授权\n列表" icon:nil backgroundColor:[UIColor flatOrangeColor] callback:^BOOL(MGSwipeTableCell * _Nonnull cell) {
        WZBDeviceObject *object = [self objectInCell:cell];
        WZBGrantListViewController *vc = [[WZBGrantListViewController alloc] initWithDeviceObject:object];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        return YES;
    }];
}

- (MGSwipeButton *)deleteDeviceButton {
    return [MGSwipeButton buttonWithTitle:@"解除\n绑定" icon:nil backgroundColor:[UIColor flatRedColor] callback:^BOOL(MGSwipeTableCell * _Nonnull cell) {
        
        WZBDeviceObject *object = [self objectInCell:cell];
        
        SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:@"警报" andMessage:@"你确定要解除绑定这个设备吗"];
        [alertView addButtonWithTitle:@"暂不解绑" type:SIAlertViewButtonTypeCancel handler:nil];
        [alertView addButtonWithTitle:@"确定解绑" type:SIAlertViewButtonTypeDestructive handler:^(SIAlertView *alertView) {
            [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
                request.api = @"/v3/enduser/unbindDevice/";
                request.httpMethod = kXMHTTPMethodPUT;
                request.parameters = @{@"deviceid":object.device_id};
                request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
            } onSuccess:^(id  _Nullable responseObject) {
                NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
                if (code==0) {
                NSLog(@"[INFO] - 解除绑定接口 调用成功");
              
                [self.deviceArray removeObject:object];
                [self.tableView beginUpdates];
                [self.tableView deleteRowsAtIndexPaths:@[[self.tableView indexPathForCell:cell]]
                                      withRowAnimation:UITableViewRowAnimationFade];
                [self.tableView endUpdates];
               

                }
            } onFailure:^(NSError * _Nullable error) {
                NSLog(@"[ERROR] - 解除绑定接口 调用失败: %@", error.localizedDescription);
            }];
        }];
        [alertView show];
        
        return YES;
    }];
}

#pragma mark - Easy Getter

- (WZBDeviceObject *)objectInCell:(MGSwipeTableCell *)cell {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    WZBDeviceObject *object = [self.deviceArray objectAtIndex:indexPath.row];
    return object;
}

- (void)sendMetaObjectBack:(NSString *)string {
    
    NSDictionary *dict = (NSDictionary *)[string wzb_jsonValueDecoded];
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"/v3/enduser/grantDevice/";
        request.headers = @{@"Authorization":[NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
        request.parameters = @{@"deviceid":dict[@"deviceid"],
                               @"vercode":dict[@"vercode"],
                               @"bindingtype":@"home"};
        
    } onFinished:^(id  _Nullable responseObject, NSError * _Nullable error) {
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
        [self.tableView.mj_header beginRefreshing];
        }
    }];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
