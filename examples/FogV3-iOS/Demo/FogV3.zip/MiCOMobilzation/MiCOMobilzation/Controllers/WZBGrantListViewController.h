//
//  WZBGrantListViewController.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class WZBDeviceObject;

@interface WZBGrantListViewController : UIViewController
- (instancetype)initWithDeviceObject:(WZBDeviceObject *)object;
@end
