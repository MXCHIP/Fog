//
//  WZBGenerateQRCodeViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/20.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBGenerateQRCodeViewController.h"
#import "WZBAppUtils.h"
#import "NSDictionary+WZBSafeAccess.h"
#import "NSDictionary+WZBJSONString.h"
@import CoreImage;
@import XMNetworking;
@import PureLayout;

@interface WZBGenerateQRCodeViewController ()
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) WZBDeviceObject *object;
@end

@implementation WZBGenerateQRCodeViewController

- (instancetype)initWithObject:(WZBDeviceObject *)object {
    if (self = [super init]) {
        self.object = object;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.imageView = [UIImageView newAutoLayoutView];
    [self.view addSubview:_imageView];
    
    [_imageView autoSetDimensionsToSize:CGSizeMake(200, 200)];
    [_imageView autoCenterInSuperview];

//    [self generateQRCode];
    self.title = @"分享设备";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setObject:(WZBDeviceObject *)object {
    _object = object;
    
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api = @"/v3/enduser/shareCode/";
        request.httpMethod = kXMHTTPMethodPOST;
        request.parameters = @{@"deviceid":object.device_id,@"role":@(3),@"granttimes":@(0)};
        request.headers = @{@"Authorization": [NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
    } onSuccess:^(id  _Nullable responseObject) {
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
        NSLog(@"[INFO] 获取绑定验证码成功 - %@", responseObject);
        NSDictionary *responoseDic = (NSDictionary *)responseObject;
        NSString *vercode = responoseDic[@"data"][@"vercode"];
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic wzb_setString:object.device_id forKey:@"deviceid"];
        [dic wzb_setString:object.device_pw forKey:@"devicepw"];
        [dic wzb_setString:vercode forKey:@"vercode"];
        [self generateQRCode:[dic wzb_JSONString]];
        }
    } onFailure:^(NSError * _Nullable error) {
        NSLog(@"[ERROR] 获取验证码失败 - %@", error.localizedDescription);
    }];
}

#pragma mark -
-(void)generateQRCode:(NSString *)jsonString
{
    //二维码滤镜
    CIFilter *filter=[CIFilter filterWithName:@"CIQRCodeGenerator"];
    //恢复滤镜的默认属性
    [filter setDefaults];
    //将字符串转换成NSData
    NSData *data=[jsonString dataUsingEncoding:NSUTF8StringEncoding];
    //通过KVO设置滤镜inputmessage数据
    [filter setValue:data forKey:@"inputMessage"];
    //获得滤镜输出的图像
    CIImage *outputImage=[filter outputImage];
    //将CIImage转换成UIImage,并放大显示
    self.imageView.image=[self createNonInterpolatedUIImageFormCIImage:outputImage withSize:100.0];
}



//改变二维码大小

- (UIImage *)createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size {
    
    CGRect extent = CGRectIntegral(image.extent);
    CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
    // 创建bitmap;
    size_t width = CGRectGetWidth(extent) * scale;
    
    size_t height = CGRectGetHeight(extent) * scale;
    
    CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
    
    CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
    
    CIContext *context = [CIContext contextWithOptions:nil];
    
    CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
    
    CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
    
    CGContextScaleCTM(bitmapRef, scale, scale);
    
    CGContextDrawImage(bitmapRef, extent, bitmapImage);
    
    // 保存bitmap到图片
    
    CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
    
    CGContextRelease(bitmapRef);
    
    CGImageRelease(bitmapImage);
    
    return [UIImage imageWithCGImage:scaledImage];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
