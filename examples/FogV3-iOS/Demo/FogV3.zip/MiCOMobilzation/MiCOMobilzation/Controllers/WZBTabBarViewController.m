//
//  WZBTabBarViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBTabBarViewController.h"
#import "WZBDevicesViewController.h"
#import "WZBMineViewController.h"
#import "UIImage+WZBAdd.h"
#import "UIColor+WZBAdd.h"

@interface WZBTabBarViewController ()

@end

@implementation WZBTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[UITabBarItem appearance] setTitlePositionAdjustment:UIOffsetMake(0, -3)];
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(-60, -60)
                                                         forBarMetrics:UIBarMetricsDefault];

    [[UIBarButtonItem appearance] setTintColor:[UIColor wzb_colorWithHexString:@"#00c1e1"]];
    
    WZBDevicesViewController *deviceVC = [[WZBDevicesViewController alloc] init];
    deviceVC.title = @"设备列表";
    UINavigationController *deviceNav = [[UINavigationController alloc] initWithRootViewController:deviceVC];
    [self addChildVc:deviceNav image:@"home_gray_128" selectedImage:@"home_blue_128"];
    
    WZBMineViewController *meVC = [[WZBMineViewController alloc] init];
    meVC.title = @"个人中心";
    UINavigationController *meNav = [[UINavigationController alloc] initWithRootViewController:meVC];
    [self addChildVc:meNav image:@"mine_gray_128" selectedImage:@"mine_blue_128"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addChildVc:(UIViewController *)childVc image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    // 设置子控制器的图片
    childVc.tabBarItem.image = [[UIImage imageNamed:image] wzb_imageByResizeToSize:CGSizeMake(25, 25)];
    childVc.tabBarItem.selectedImage = [[[UIImage imageNamed:selectedImage]
                                         wzb_imageByResizeToSize:CGSizeMake(25, 25)]
                                        imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    // 设置文字的样式
    NSMutableDictionary *textAttrs = [NSMutableDictionary dictionary];
    textAttrs[NSForegroundColorAttributeName] = [UIColor wzb_colorWithHexString:@"#333333"];
    NSMutableDictionary *selectTextAttrs = [NSMutableDictionary dictionary];
    selectTextAttrs[NSForegroundColorAttributeName] = [UIColor wzb_colorWithHexString:@"#00c1e1"];
    [childVc.tabBarItem setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [childVc.tabBarItem setTitleTextAttributes:selectTextAttrs forState:UIControlStateSelected];
    
    // 添加为子控制器
    [self addChildViewController:childVc];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
