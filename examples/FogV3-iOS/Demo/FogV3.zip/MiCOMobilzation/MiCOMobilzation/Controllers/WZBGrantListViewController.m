//
//  WZBGrantListViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBGrantListViewController.h"
#import "WZBDeviceObject.h"
#import "WZBAppUtils.h"
#import "WZBGrantUserObject.h"
@import SVProgressHUD;
@import XMNetworking;

@interface WZBGrantListViewController () <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) WZBDeviceObject *object;
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation WZBGrantListViewController {
    NSArray *resultArray;
}

- (instancetype)initWithDeviceObject:(WZBDeviceObject *)object {
    if (self = [super init]) {
        self.object = object;
    }
    return self;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        
        _tableView.tableFooterView = [UIView new];
        _tableView.estimatedRowHeight = 100;
        _tableView.rowHeight = UITableViewAutomaticDimension;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"授权列表";
    [self.view addSubview:self.tableView];
    // Do any additional setup after loading the view.

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [resultArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    WZBGrantUserObject *object = resultArray[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"已授权给: %@", object.phone];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)setObject:(WZBDeviceObject *)object {
    _object = object;
    
    [SVProgressHUD show];
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.headers = @{@"Authorization":[NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
        request.httpMethod = kXMHTTPMethodGET;
        request.api = @"/v3/enduser/enduserList/";
        request.parameters = @{@"deviceid": self.object.device_id};
    } onSuccess:^(id  _Nullable responseObject) {
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
        NSLog(@"[INFO] - 获取授权列表接口正确: %@", responseObject);
        resultArray = [WZBGrantUserObject mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
        [SVProgressHUD showSuccessWithStatus:@"成功获取授权列表"];
        [SVProgressHUD dismissWithDelay:1.0];
       
        [self.tableView reloadData];
       
        }else
        {
            [SVProgressHUD showSuccessWithStatus:@"获取授权列表失败"];
            [SVProgressHUD dismissWithDelay:1.0];
        }
    } onFailure:^(NSError * _Nullable error) {
        NSLog(@"[ERROR] - 获取授权列表接口错误: %@", error.localizedDescription);
    }];
}

-(NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewRowAction *deleteRowAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"移除授权" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        
        [self removeBindRole:indexPath.row];
        
    }];
    
    return @[deleteRowAction];
}
-(void)removeBindRole:(NSInteger)row
{
    WZBGrantUserObject *model=resultArray[row];
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.headers = @{@"Authorization":[NSString stringWithFormat:@"JWT %@", [[WZBAppUtils sharedUtil] token]]};
        request.httpMethod = kXMHTTPMethodPUT;
        request.api = @"/v3/enduser/removeBindRole/";
        request.parameters = @{@"deviceid": self.object.device_id ,@"enduserid":model.enduserid};
    } onSuccess:^(id  _Nullable responseObject) {
        
        NSInteger code=(NSInteger)responseObject[@"meta"][@"code"];
        if (code==0) {
            resultArray = [WZBGrantUserObject mj_objectArrayWithKeyValuesArray:responseObject[@"data"]];
            [SVProgressHUD showSuccessWithStatus:@"成功获取授权列表"];
            [SVProgressHUD dismissWithDelay:1.0];
            
        }else
        {
            [SVProgressHUD showSuccessWithStatus:[NSString stringWithFormat:@"失败：%@",responseObject[@"meta"][@"message"]]];
            [SVProgressHUD dismissWithDelay:1.0];
        }
        [self.tableView reloadData];
    } onFailure:^(NSError * _Nullable error) {
        
    }];
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
