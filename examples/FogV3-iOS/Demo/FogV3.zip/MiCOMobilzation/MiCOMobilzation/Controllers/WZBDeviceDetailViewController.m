//
//  WZBDeviceDetailViewController.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBDeviceDetailViewController.h"
#import "WZBDeviceDetailTableViewCell.h"
#import "MQTTClient.h"
#import "XMNetworking.h"
#import "WZBAppUtils.h"
#import "SVProgressHUD.h"
#import "NSDictionary+WZBSafeAccess.h"
#import "NSDictionary+WZBJSONString.h"
#import "MJExtension.h"
#import "WZBHSBColorViewController.h"
#import "MqttInfo.h"
@import SAMKeychain;

@interface WZBDeviceInfoObject : NSObject
@property (nonatomic ,assign) NSInteger DeviceMode;

@property (nonatomic ,assign) NSInteger Humidity;

@property (nonatomic ,assign) NSInteger Temperature;

@property (nonatomic ,assign) NSInteger MotorSpeed;

@property (nonatomic ,assign) NSInteger MsgType;

@property (nonatomic ,assign) NSInteger PM2_5;

@property (nonatomic ,strong) NSString *deviceid;

@property (nonatomic ,assign) NSInteger CO2;

@end

@implementation WZBDeviceInfoObject
@end

@interface WZBDeviceDetailViewController () <MQTTSessionDelegate>
@property(nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) WZBDeviceInfoObject *deviceInfoObject;

@property (nonatomic,strong)MqttInfo *mqttInfo;
@property (nonatomic,strong)MQTTSession *mqttSession;

@property (nonatomic,weak)UITextView *sendTextView;
@property (nonatomic,weak)UITextView *receiveView;
@end

@implementation WZBDeviceDetailViewController {
    NSArray *testDataSource;
    NSArray *testDataSourceUnit;
    NSArray *subscrbedTopics;
}


#pragma mark - Setter
- (void)setDeviceObject:(WZBDeviceObject *)deviceObject {
    _deviceObject = deviceObject;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}
-(void)viewDidLoad
{
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets=NO;
    [self setUpUI];
    [self startMQTTService];
    
}
-(void)setUpUI
{
    UILabel *sendLabel=[[UILabel alloc]initWithFrame:CGRectMake(10, 100, 200, 40)];
    sendLabel.text=@"发送指令输入";
    [self.view addSubview:sendLabel];
    
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    btn.backgroundColor=[UIColor blueColor];
    btn.frame=CGRectMake([UIScreen mainScreen].bounds.size.width-120, 100, 100, 40);
    [btn setTitle:@"发送" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(sendClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(10, 150, [UIScreen mainScreen].bounds.size.width - 20, 100)];
    
    textView.font = [UIFont fontWithName:@"Arial" size:16.5f];
    
    textView.textColor = [UIColor colorWithRed:51/255.0f green:51/255.0f blue:51/255.0f alpha:1.0f];
    
    textView.backgroundColor = [UIColor colorWithRed:187/255.0f green:194/255.0f blue:201/255.0f alpha:1.0f];
    
    textView.textAlignment = NSTextAlignmentLeft;
    
    [self.view addSubview:textView];
    self.sendTextView=textView;
    
    UILabel *receiveLabel=[[UILabel alloc]initWithFrame:CGRectMake(10, 260, 200, 40)];
    receiveLabel.text=@"接收数据显示";
    [self.view addSubview:receiveLabel];
    
    UITextView *receiveView = [[UITextView alloc] initWithFrame:CGRectMake(10, 310, [UIScreen mainScreen].bounds.size.width - 20, 220)];
    
    receiveView.font = [UIFont fontWithName:@"Arial" size:16.5f];
    
    receiveView.textColor = [UIColor colorWithRed:51/255.0f green:51/255.0f blue:51/255.0f alpha:1.0f];
    
    receiveView.backgroundColor = [UIColor colorWithRed:187/255.0f green:194/255.0f blue:201/255.0f alpha:1.0f];
    
    receiveView.textAlignment = NSTextAlignmentLeft;
    receiveView.scrollEnabled=YES;
    receiveView.editable=NO;
    [self.view addSubview:receiveView];
    self.receiveView=receiveView;
    
}
-(void)sendClick
{
    [self publishData];
}
-(void)startMQTTService
{
    [XMCenter sendRequest:^(XMRequest * _Nonnull request) {
        request.api=@"/v3/enduser/mqttInfo/";
        request.httpMethod=kXMHTTPMethodGET;
        request.headers=@{@"Authorization":[NSString stringWithFormat:@"JWT %@", [WZBAppUtils sharedUtil].token]};
        
    } onSuccess:^(id  _Nullable responseObject) {
        
        NSInteger code=[[[responseObject objectForKey:@"meta"] objectForKey:@"code"] integerValue];
        if (code==0) {
            self.mqttInfo=[MqttInfo mj_objectWithKeyValues:responseObject[@"data"]];
            [self startMqtt];
            
        }
        
    } onFailure:^(NSError * _Nullable error) {
        
    }];
    
    
}
-(void)startMqtt
{
    MQTTCFSocketTransport *transport=[[MQTTCFSocketTransport alloc]init];
    transport.host=self.mqttInfo.mqtthost;
    transport.port=(UInt32)self.mqttInfo.mqttport;
    
    self.mqttSession=[[MQTTSession alloc]init];
    self.mqttSession.transport=transport;
    self.mqttSession.delegate=self;
    
    self.mqttSession.userName = self.mqttInfo.loginname;
    self.mqttSession.clientId = self.mqttInfo.clientid;
    self.mqttSession.password = self.mqttInfo.password;
    
    [self.mqttSession connectToHost:transport.host port:transport.port usingSSL:NO connectHandler:^(NSError *error) {
        if (error) {
            NSLog(@"---连接失败：%@",error.localizedDescription);
        }else
        {
            
            [self subscribeTopics];
            
        }
        
    }];
    
}
-(void)subscribeTopics
{
    NSString *status=[NSString stringWithFormat:@"%@/%@/%@/status/json",self.mqttInfo.endpoint,self.deviceObject.product_id,self.deviceObject.device_id];
    
    [self.mqttSession subscribeToTopic:status atLevel:MQTTQosLevelAtMostOnce subscribeHandler:^(NSError *error, NSArray<NSNumber *> *gQoss) {
        
        if (error) {
            NSLog(@"---订阅失败：%@",error.localizedDescription);
        }else
        {
            NSLog(@"---订阅成功");
        }
        
    }];
    
}
-(void)publishData
{
    NSString *topic=[NSString stringWithFormat:@"%@/%@/%@/command/json",self.mqttInfo.endpoint,self.deviceObject.product_id,self.deviceObject.device_id];
    NSMutableDictionary *dict=[NSMutableDictionary dictionary];
    
    [dict setObject:self.sendTextView.text forKey:@"payload"];
    NSData *data =[NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
    
    [self.mqttSession publishData:data onTopic:topic retain:NO qos:MQTTQosLevelAtMostOnce publishHandler:^(NSError *error) {
        
        if (!error) {
            
            [SVProgressHUD showSuccessWithStatus:@"发送成功"];
            [SVProgressHUD dismissWithDelay:0.5];
        }else
        {
            NSLog(@"---%@",error.localizedDescription);
        }
        
    }];
    
}


#pragma mark - MQTT Delegate
- (void)newMessage:(MQTTSession *)session data:(NSData *)data onTopic:(NSString *)topic qos:(MQTTQosLevel)qos retained:(BOOL)retained mid:(unsigned int)mid {
    
    NSString *oldText=self.receiveView.text;
    NSString *nowText=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    
    self.receiveView.text=[NSString stringWithFormat:@"%@\n\n\n%@",nowText,oldText];
    
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.mqttSession unsubscribeTopics:subscrbedTopics];
    [self.mqttSession disconnect];
    [self.mqttSession close];
    self.mqttSession = nil;
}

@end
