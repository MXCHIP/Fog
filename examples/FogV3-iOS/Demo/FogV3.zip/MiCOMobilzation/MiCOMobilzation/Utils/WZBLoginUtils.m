//
//  WZBLoginUtils.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBLoginUtils.h"
#import "WZBLoginViewController.h"
#import "WZBAppUtils.h"
@implementation WZBLoginUtils
+ (void)showLoginController {
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    UIViewController *rootController = (UIViewController *)window.rootViewController;
    
    WZBLoginViewController *vc = [[WZBLoginViewController alloc] init];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [rootController presentViewController:nav animated:YES completion:nil];
    });
}

+ (BOOL)isUserLogin {
    return [[[WZBAppUtils sharedUtil] token] length] != 0;
}
@end
