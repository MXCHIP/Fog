//
//  WZBAppUtils.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBAppUtils.h"
#import "NSUserDefaults+WZBSafeAccess.h"
#import "WZBLoginUtils.h"

@implementation WZBAppUtils

+ (instancetype)sharedUtil {
    static WZBAppUtils *util = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        util = [[WZBAppUtils alloc] init];
    });
    return util;
}

- (NSString *)appid {
    return @"ffcdcf92-7684-11e7-8d17-00163e03b4d6";
}

- (void)saveClientId:(NSString *)clientId {
    [NSUserDefaults wzb_setObject:clientId forKey:@"clientid"];
    NSLog(@"保存 clientId 成功");
}

- (NSString *)clientId {
    return [NSUserDefaults wzb_stringFroKey:@"clientid"];
}

- (void)saveToken:(NSString *)token {
    [NSUserDefaults wzb_setObject:token forKey:@"token"];
    NSLog(@"保存 token 成功");
}

- (void)removeToken {
    [NSUserDefaults wzb_setObject:nil forKey:@"token"];
    [WZBLoginUtils showLoginController];
}

- (NSString *)token {
    return [NSUserDefaults wzb_stringFroKey:@"token"];
}
@end
