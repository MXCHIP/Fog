//
//  WZBAppUtils.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZBAppUtils : NSObject

+ (instancetype)sharedUtil;
- (NSString *)appid;

//+ (NSString *)productid;

- (NSString *)token;
- (void)saveToken:(NSString *)token;
- (void)removeToken;

- (NSString *)clientId;
- (void)saveClientId:(NSString *)clientId;

@end
