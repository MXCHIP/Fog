//
//  WZBDeviceTableViewCell.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <SWTableViewCell/SWTableViewCell.h>
#import "MGSwipeTableCell.h"

#import "WZBDeviceObject.h"

@interface WZBDeviceTableViewCell : MGSwipeTableCell
@property (nonatomic, strong) WZBDeviceObject *object;
@end
