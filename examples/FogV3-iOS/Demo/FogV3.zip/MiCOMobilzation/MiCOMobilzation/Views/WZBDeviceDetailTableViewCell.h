//
//  WZBDeviceDetailTableViewCell.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, UnitLabelType) {
    UnitLabelTypeHide = 0,
    UnitLabelTypeOnlineStatus = 1,
    UnitLabelTypeUnit = 2,
};

typedef NS_ENUM(NSUInteger, SwitchType) {
    SwitchTypeShown = 0,
    SwitchTypeNotShown,
};

typedef void (^DetailCellSwitchBlock)(UISwitch *theSwitch);

@interface WZBDeviceDetailTableViewCell : UITableViewCell
@property(nonatomic, strong) NSString *nameString;
@property(nonatomic, strong) NSString *unitString;
@property (nonatomic, strong) NSString *valueString;
@property(nonatomic, assign) UnitLabelType labelType;
@property (nonatomic, assign) SwitchType switchType;

- (void)wzb_addSwitchHandler:(DetailCellSwitchBlock)handler;
@end
