//
//  WZBDeviceDetailTableViewCell.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBDeviceDetailTableViewCell.h"
#import "PureLayout.h"
#import "UIImage+WZBAdd.h"
#import "NSString+WZBAdd.h"
#import "UIView+WZBAddCorner.h"
#import <objc/runtime.h>
#import "Chameleon.h"

static const void *wzb_switchCellBlockKey = &wzb_switchCellBlockKey;

@interface WZBDeviceDetailTableViewCell ()
@property(nonatomic, strong) UIImageView *logoImageView;
@property(nonatomic, strong) UILabel *nameLabel;
@property(nonatomic, strong) UILabel *valueLabel;
@property(nonatomic, strong) UILabel *unitLabel;//显示在线或者单位
@property(nonatomic, strong) UISwitch *theSwitch;
@end

@implementation WZBDeviceDetailTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.logoImageView = [UIImageView newAutoLayoutView];
        [self.contentView addSubview:_logoImageView];
        self.logoImageView.contentMode = UIViewContentModeScaleAspectFill;
        
        [self.logoImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
        [self.logoImageView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10];
        [self.logoImageView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10];
        [self.logoImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.logoImageView autoSetDimension:ALDimensionWidth toSize:30.0f];
        
        [self.logoImageView setImage:[[UIImage imageNamed:@"case_blue_128"] wzb_imageByResizeToSize:CGSizeMake(30, 30)]];
        
        self.nameLabel = [UILabel newAutoLayoutView];
        [self.contentView addSubview:_nameLabel];
        
        _nameLabel.text = @"micokit-XXX";
        _nameLabel.font = [UIFont systemFontOfSize:14];
        [_nameLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.logoImageView];
        [_nameLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.logoImageView withOffset:15.0f];
        
        self.unitLabel = [UILabel newAutoLayoutView];
        [self.contentView addSubview:_unitLabel];
        
        _unitLabel.backgroundColor = [UIColor redColor];
        _unitLabel.text = @"离线";
        
        [_unitLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.nameLabel];
        [_unitLabel autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10.0f];
        _unitLabel.font = [UIFont systemFontOfSize:10];
        _unitLabel.textColor = [UIColor whiteColor];
        _unitLabel.textAlignment = NSTextAlignmentCenter;
        [_unitLabel autoSetDimension:ALDimensionWidth toSize:[_unitLabel.text wzb_sizeWithFont:[UIFont systemFontOfSize:16] constrainedToWidth:80].width];
        [_unitLabel autoSetDimension:ALDimensionHeight toSize:[_unitLabel.text wzb_sizeWithFont:[UIFont systemFontOfSize:17] constrainedToWidth:60].height];
        
        self.valueLabel = [UILabel newAutoLayoutView];
        [self.contentView addSubview:_valueLabel];
        
        [self.valueLabel autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.valueLabel autoPinEdge:ALEdgeTrailing toEdge:ALEdgeLeading ofView:self.unitLabel withOffset:-5.0f*2];
        self.valueLabel.text = @"165";
        
        
        self.theSwitch = [UISwitch newAutoLayoutView];
        [self.contentView addSubview:_theSwitch];
        
        [_theSwitch autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [_theSwitch autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10.0f];
        _theSwitch.hidden = YES;
        

    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)layoutSubviews {
    [super layoutSubviews];
//    [_unitLabel sizeToFit];
    [_unitLabel wzb_addCustomCornerWithSize:CGSizeMake(5*2, 5*2)];

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setNameString:(NSString *)nameString {
    _nameString = nameString;
    self.nameLabel.text = _nameString;
}

- (void)setLabelType:(UnitLabelType)labelType {
    switch (labelType) {
        case UnitLabelTypeHide:
            self.unitLabel.hidden = YES;
            self.valueLabel.hidden = YES;
            break;
        case UnitLabelTypeUnit:
            self.unitLabel.hidden = NO;
            self.unitLabel.backgroundColor = [UIColor flatOrangeColor];
            
            break;
        case UnitLabelTypeOnlineStatus:
            self.unitLabel.hidden = NO;
            self.valueLabel.hidden = YES;
            self.unitLabel.backgroundColor = [UIColor greenColor];
            break;
    }
}

- (void)wzb_addSwitchHandler:(DetailCellSwitchBlock)handler {
    objc_setAssociatedObject(self, wzb_switchCellBlockKey, handler, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self.theSwitch addTarget:self action:@selector(wzb_blockActionValueChanged:) forControlEvents:UIControlEventValueChanged];
}

- (void)wzb_blockActionValueChanged:(UISwitch *)s {
    DetailCellSwitchBlock block = objc_getAssociatedObject(self, wzb_switchCellBlockKey);
    if (block) {
        block(s);
    }
}

- (void)setUnitString:(NSString *)unitString {
    if ([unitString isEqualToString:@"在线"]) {
        self.unitLabel.backgroundColor = [UIColor flatLimeColor];
    } else if ([unitString isEqualToString:@"离线"]) {
        self.unitLabel.backgroundColor = [UIColor flatRedColor];
    }
    self.unitLabel.text = unitString;
    [self.unitLabel setNeedsLayout];
    [self.unitLabel layoutIfNeeded];
}

- (void)setValueString:(NSString *)valueString {
    _valueString = valueString;
    if ([valueString isEqualToString:@"0"]) {
        self.valueLabel.text = @"正在获取...";
        self.valueLabel.font = [UIFont systemFontOfSize:15];
        self.valueLabel.textColor = [UIColor flatBlackColor];
    } else {
        self.valueLabel.text = valueString;
        self.valueLabel.font = [UIFont systemFontOfSize:17];
        self.valueLabel.textColor = [UIColor flatGrayColor];
    }
}

- (void)setSwitchType:(SwitchType)switchType {
    switch (switchType) {
        case SwitchTypeShown:
            self.theSwitch.hidden = NO;
            break;
        case SwitchTypeNotShown:
            self.theSwitch.hidden = YES;
            break;
    }
}
@end
