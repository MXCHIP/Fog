//
//  WZBConfigureView.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZBConfigureView : UIView
@property (nonatomic, strong, readwrite) UIButton *startButton;
@property (nonatomic, strong, readwrite) UITextField *ssidTextField;
@property (nonatomic, strong, readwrite) UITextField *passwordTextField;
@end
