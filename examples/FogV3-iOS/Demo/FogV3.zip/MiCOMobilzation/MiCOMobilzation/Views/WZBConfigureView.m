//
//  WZBConfigureView.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBConfigureView.h"
#import "PureLayout.h"
#import "UIButton+WZBBackgroundColor.h"
#import "UIImage+WZBAdd.h"
#import "UIView+WZBAddCorner.h"
#import "UIColor+WZBAdd.h"

@interface WZBLeftPaddingTextField : UITextField
@end

@implementation WZBLeftPaddingTextField
- (CGRect)leftViewRectForBounds:(CGRect)bounds {
    CGRect iconRect = [super leftViewRectForBounds:bounds];
    iconRect.origin.x += 5;
    return iconRect;
}

- (CGRect)textRectForBounds:(CGRect)bounds {
    return CGRectInset(bounds, 45, 0);
}

- (CGRect)editingRectForBounds:(CGRect)bounds{
    return CGRectInset(bounds, 45, 0);
}
@end

@interface WZBConfigureView ()
@property (nonatomic, strong) UIView *seperateLine;
@end

@implementation WZBConfigureView
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        //
        self.ssidTextField = [WZBLeftPaddingTextField newAutoLayoutView];
        [self addSubview:_ssidTextField];
        
        _ssidTextField.leftViewMode = UITextFieldViewModeAlways;
        _ssidTextField.leftView = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"wifi_blue_128"] wzb_imageByResizeToSize:CGSizeMake(30, 30)]];
        
        [_ssidTextField autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:5.0f];
        [_ssidTextField autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10.0f];
        [_ssidTextField autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:10.0f];
        [_ssidTextField autoSetDimension:ALDimensionHeight toSize:50.0f];
        //        _firstTextField.text = @"mxchip-rd";
        _ssidTextField.textAlignment = NSTextAlignmentLeft;
        
        self.seperateLine = [UIView newAutoLayoutView];
        [self addSubview:_seperateLine];
        
        _seperateLine.backgroundColor = [UIColor lightGrayColor];
        [_seperateLine autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.ssidTextField];
        [_seperateLine autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.ssidTextField];
        [_seperateLine autoSetDimension:ALDimensionHeight toSize:1.0f];
        [_seperateLine autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.ssidTextField withOffset:3.0f];
        
        self.passwordTextField = [WZBLeftPaddingTextField newAutoLayoutView];
        [self addSubview:_passwordTextField];
        
        _passwordTextField.leftViewMode = UITextFieldViewModeAlways;
        _passwordTextField.leftView = [[UIImageView alloc] initWithImage:[[UIImage imageNamed:@"wifipsw_blue_128"] wzb_imageByResizeToSize:CGSizeMake(30, 30)]];
        
        [_passwordTextField autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.ssidTextField];
        [_passwordTextField autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.ssidTextField withMultiplier:0.75];
        [_passwordTextField autoMatchDimension:ALDimensionHeight toDimension:ALDimensionHeight ofView:self.ssidTextField];
        [_passwordTextField autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.seperateLine withOffset:3.0f];;
        
        _passwordTextField.textAlignment = _ssidTextField.textAlignment;
        //        _secondTextField.text = @"12345678";

        self.startButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.startButton.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:_startButton];
        
        [_startButton autoMatchDimension:ALDimensionWidth toDimension:ALDimensionWidth ofView:self.ssidTextField];
        [_startButton autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.ssidTextField];
        [_startButton autoSetDimension:ALDimensionHeight toSize:44.0f];
        [_startButton setTitle:@"开始配网" forState:UIControlStateNormal];
        [_startButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passwordTextField withOffset:5.0f];
        [_startButton wzb_setBackgroundColor:[UIColor wzb_colorWithHexString:@"00c1e1"] forState:UIControlStateNormal];
        
        [_startButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:10.0f];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [_startButton wzb_addCustomCornerWithSize:CGSizeMake(10*2, 10*2)];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
