//
//  WZBDeviceTableViewCell.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "WZBDeviceTableViewCell.h"
#import "PureLayout.h"
#import "UIImage+WZBAdd.h"
#import "NSString+WZBAdd.h"
#import "UIView+WZBAddCorner.h"
#import "NSString+WZBAdd.h"
#import "UIView+WZBFrame.h"
#import "Chameleon.h"

@interface WZBDeviceTableViewCell ()
@property(nonatomic, strong) UILabel *nameLabel;
@property(nonatomic, strong) UILabel *macLabel;
@property(nonatomic, strong) UILabel *statusLabel;
@property(nonatomic, strong) UIImageView *deviceImageView;
@end

@implementation WZBDeviceTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.deviceImageView = [UIImageView newAutoLayoutView];
        [self.contentView addSubview:_deviceImageView];
        self.deviceImageView.contentMode = UIViewContentModeScaleAspectFill;
        
        [self.deviceImageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:20];
        [self.deviceImageView autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:10];
        [self.deviceImageView autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:20];
        [self.deviceImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
        [self.deviceImageView autoSetDimension:ALDimensionWidth toSize:50.0f];
        
        [self.deviceImageView setImage:[[UIImage imageNamed:@"device_gray_200"] wzb_imageByResizeToSize:CGSizeMake(40, 40)]];
        //        [self.deviceImageView setBackgroundColor:[UIColor redColor]];
        
        self.nameLabel = [UILabel newAutoLayoutView];
        [self.contentView addSubview:_nameLabel];
        
        _nameLabel.text = @"micokit-XXX";
        _nameLabel.font = [UIFont systemFontOfSize:14];
        [_nameLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.deviceImageView withOffset:-10.0f];
        [_nameLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeTrailing ofView:self.deviceImageView withOffset:20.0f];
        
        self.macLabel  = [UILabel newAutoLayoutView];
        [self.contentView addSubview:_macLabel];
        
        _macLabel.text = @"MAC: D0:BA:E4:18:72:6C";
        _macLabel.font = [UIFont systemFontOfSize:11];
        _macLabel.textColor = [UIColor lightGrayColor];
        
        [_macLabel autoPinEdge:ALEdgeLeading toEdge:ALEdgeLeading ofView:self.nameLabel];
        [_macLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.deviceImageView withOffset:10.0];
        
        self.statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        [self.contentView addSubview:_statusLabel];
        _statusLabel.font = [UIFont systemFontOfSize:12];
        _statusLabel.textColor = [UIColor whiteColor];
        _statusLabel.textAlignment = NSTextAlignmentCenter;
        

        self.accessoryView = self.statusLabel;
    }
    return self;
}

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated {
    [super setHighlighted:highlighted animated:animated];
    
    UIColor *color = self.statusLabel.backgroundColor;
    if (highlighted) {
        self.statusLabel.backgroundColor = color;
    }
}

//- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
//   
//    [super setSelected:selected animated:animated];
//    UIColor *color = self.statusLabel.backgroundColor;
//    if (selected) {
//        self.statusLabel.backgroundColor = color;
//    }
//}

- (void)layoutSubviews {
    [super layoutSubviews];
    
//    _statusLabel.backgroundColor = [UIColor redColor];
    [_statusLabel wzb_addCustomCornerWithSize:CGSizeMake(5*2, 5*2)];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)setObject:(WZBDeviceObject *)object {
    self.nameLabel.text = object.device_name;
    self.macLabel.text = [@"MAC: " stringByAppendingString:object.mac];
    self.statusLabel.text = object.online == YES ? @"在线" : @"离线";
    self.statusLabel.backgroundColor = object.online == YES ? [UIColor flatLimeColor] : [UIColor flatRedColor];
    
    [_statusLabel sizeToFit];
    [_statusLabel setWzb_width:[self.statusLabel.text wzb_sizeWithFont:[UIFont systemFontOfSize:16] constrainedToWidth:60].width];
    [_statusLabel setWzb_height:[self.statusLabel.text wzb_sizeWithFont:[UIFont systemFontOfSize:16] constrainedToWidth:60].height];
}

@end
