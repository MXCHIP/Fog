//
//  NSIndexPath+WZBOffset.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSIndexPath (WZBOffset)

- (NSIndexPath *)wzb_previousRow;
- (NSIndexPath *)wzb_nextRow;

- (NSIndexPath *)wzb_previousItem;
- (NSIndexPath *)wzb_nextItem;

- (NSIndexPath *)wzb_previousSection;
- (NSIndexPath *)wzb_nextSection;

@end
