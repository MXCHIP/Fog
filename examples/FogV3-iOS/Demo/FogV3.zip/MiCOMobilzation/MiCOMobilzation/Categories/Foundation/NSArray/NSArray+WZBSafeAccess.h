//
//  NSArray+WZBSafeAccess.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSArray (WZBSafeAccess)
- (id)wzb_objectWithIndex:(NSUInteger)index;
- (NSString *)wzb_stringWithIndex:(NSUInteger)index;
- (NSNumber *)wzb_numberWithIndex:(NSUInteger)index;
- (NSDecimalNumber *)wzb_decimalNumberWithIndex:(NSUInteger)index;
- (NSArray *)wzb_arrayWithIndex:(NSUInteger)index;
- (NSDictionary *)wzb_dictionaryWithIndex:(NSUInteger)index;
- (NSInteger)wzb_integerWithIndex:(NSUInteger)index;
- (NSUInteger)wzb_unsignedIntegerWithIndex:(NSUInteger)index;
- (BOOL)wzb_boolWithIndex:(NSUInteger)index;
- (int16_t)wzb_int16WithIndex:(NSUInteger)index;
- (int32_t)wzb_int32WithIndex:(NSUInteger)index;
- (int64_t)wzb_int64WithIndex:(NSUInteger)index;
- (char)wzb_charWithIndex:(NSUInteger)index;
- (short)wzb_shortWithIndex:(NSUInteger)index;
- (float)wzb_floatWithIndex:(NSUInteger)index;
- (double)wzb_doubleWithIndex:(NSUInteger)index;
- (NSDate *)wzb_dateWithIndex:(NSUInteger)index dateFormat:(NSString *)dateFormat;
- (CGFloat)wzb_CGFloatWithIndex:(NSUInteger)index;
- (CGPoint)wzb_pointWithIndex:(NSUInteger)index;
- (CGSize)wzb_sizeWithIndex:(NSUInteger)index;
- (CGRect)wzb_rectWithIndex:(NSUInteger)index;
@end

#pragma mark - NSMutableArray setter
@interface NSMutableArray (WZBSafeAccess)
- (void)wzb_addObject:(id)object;
- (void)wzb_addString:(NSString *)string;
- (void)wzb_addBool:(BOOL)i;
- (void)wzb_addInt:(int)i;
- (void)wzb_addInteger:(NSInteger)i;
- (void)wzb_addUnsignedInteger:(NSUInteger)i;
- (void)wzb_addCGFloat:(CGFloat)f;
- (void)wzb_addChar:(char)c;
- (void)wzb_addFloat:(float)f;
- (void)wzb_addPoint:(CGPoint)point;
- (void)wzb_addSize:(CGSize)size;
- (void)wzb_addRect:(CGRect)rect;
@end
