//
//  NSDictionary+WZBJSONString.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSDictionary+WZBJSONString.h"

@implementation NSDictionary (WZBJSONString)
- (NSString *)wzb_JSONString {
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:&error];
    if (jsonData == nil) {
#ifdef DEBUG
        NSLog(@"Failed to get JSON from dictionary: %@, error: %@", self, error);
        return nil;
#endif
    }
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}
@end
