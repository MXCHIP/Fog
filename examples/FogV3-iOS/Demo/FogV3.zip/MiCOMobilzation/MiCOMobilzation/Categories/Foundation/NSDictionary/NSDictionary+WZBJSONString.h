//
//  NSDictionary+WZBJSONString.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (WZBJSONString)
- (NSString *)wzb_JSONString;
@end
