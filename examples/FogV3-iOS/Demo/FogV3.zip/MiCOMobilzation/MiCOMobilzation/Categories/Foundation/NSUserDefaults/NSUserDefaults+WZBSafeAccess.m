//
//  NSUserDefaults+WZBSafeAccess.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSUserDefaults+WZBSafeAccess.h"

@implementation NSUserDefaults (WZBSafeAccess)

+ (NSString *)wzb_stringFroKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] stringForKey:key];
}

+ (NSArray *)wzb_arrayForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] arrayForKey:key];
}

+ (NSDictionary *)wzb_dictionaryForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] dictionaryForKey:key];
}

+ (NSData *)wzb_dataForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] dataForKey:key];
}

+ (NSArray *)wzb_stringArrayForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] stringArrayForKey:key];
}

+ (NSInteger)wzb_integerForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] integerForKey:key];
}

+ (float)wzb_floatForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] floatForKey:key];
}

+ (double)wzb_doubleForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] doubleForKey:key];
}

+ (BOOL)wzb_boolForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] boolForKey:key];
}

+ (NSURL *)wzb_URLForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] URLForKey:key];
}

+ (void)wzb_setObject:(id)value forKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)wzb_setArcObject:(id)value forKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setObject:[NSKeyedArchiver archivedDataWithRootObject:value] forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (id)wzb_arcObjectForKey:(NSString *)key {
    return [NSKeyedUnarchiver unarchiveObjectWithData:[[NSUserDefaults standardUserDefaults] objectForKey:key]];
}

@end
