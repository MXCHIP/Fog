//
//  NSData+WZBAdd.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/27.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (WZBAdd)
- (nullable id)wzb_jsonValueDecoded;
@end
