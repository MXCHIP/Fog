//
//  NSArray+WZBBlock.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/12.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (WZBBlock)
- (void)wzb_each:(void (^)(id object))block;
- (void)wzb_eachWithIndex:(void (^)(id object, NSUInteger index))block;
- (NSArray *)wzb_map:(id (^)(id object))block;
- (NSArray *)wzb_filter:(BOOL (^)(id object))block;
- (NSArray *)wzb_reject:(BOOL (^)(id object))block;
- (id)wzb_detect:(BOOL (^)(id object))block;
- (id)wzb_reduce:(id (^)(id accumulator, id object))block;
- (id)wzb_reduce:(id)initial withBlock:(id (^)(id accumulator, id object))block;
@end
