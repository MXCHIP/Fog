//
//  NSFileManager+WZBPaths.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (WZBPaths)

+ (NSURL *)wzb_documentsURL;
+ (NSString *)wzb_documentsPath;

+ (NSURL *)wzb_libraryURL;
+ (NSString *)wzb_libraryPath;

+ (NSURL *)wzb_cachesURL;
+ (NSString *)wzb_cachesPath;

+ (double)wzb_availableDiskSpace;

@end
