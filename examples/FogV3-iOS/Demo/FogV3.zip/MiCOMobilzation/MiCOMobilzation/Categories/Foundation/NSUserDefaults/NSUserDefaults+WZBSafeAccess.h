//
//  NSUserDefaults+WZBSafeAccess.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (WZBSafeAccess)

+ (NSString *)wzb_stringFroKey:(NSString *)key;
+ (NSArray *)wzb_arrayForKey:(NSString *)key;
+ (NSDictionary *)wzb_dictionaryForKey:(NSString *)key;
+ (NSData *)wzb_dataForKey:(NSString *)key;
+ (NSArray *)wzb_stringArrayForKey:(NSString *)key;
+ (NSInteger)wzb_integerForKey:(NSString *)key;
+ (float)wzb_floatForKey:(NSString *)key;
+ (double)wzb_doubleForKey:(NSString *)key;
+ (BOOL)wzb_boolForKey:(NSString *)key;
+ (NSURL *)wzb_URLForKey:(NSString *)key;

+ (void)wzb_setObject:(id)value forKey:(NSString *)key;
+ (void)wzb_setArcObject:(id)value forKey:(NSString *)key;
+ (id)wzb_arcObjectForKey:(NSString *)key;
@end
