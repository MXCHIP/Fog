//
//  NSArray+WZBBlock.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/12.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSArray+WZBBlock.h"

@implementation NSArray (WZBBlock)
- (void)wzb_each:(void (^)(id object))block {
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        block(obj);
    }];
}

- (void)wzb_eachWithIndex:(void (^)(id object, NSUInteger index))block {
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        block(obj, idx);
    }];
}

- (NSArray *)wzb_map:(id (^)(id object))block {
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:self.count];
    
    for (id object in self) {
        [array addObject:block(object) ?: [NSNull null]];
    }
    
    return array;
}

- (NSArray *)wzb_filter:(BOOL (^)(id object))block {
    return [self filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id  _Nullable evaluatedObject, NSDictionary<NSString *,id> * _Nullable bindings) {
        return block(evaluatedObject);
    }]];
}

- (NSArray *)wzb_reject:(BOOL (^)(id object))block {
    return [self filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(id  _Nullable evaluatedObject, NSDictionary<NSString *,id> * _Nullable bindings) {
        return !block(evaluatedObject);
    }]];
}

- (id)wzb_detect:(BOOL (^)(id object))block {
    for (id object in self) {
        if (block(object)) {
            return object;
        }
    }
    return nil;
}

- (id)wzb_reduce:(id (^)(id accumulator, id object))block {
    return [self wzb_reduce:nil withBlock:block];
}

- (id)wzb_reduce:(id)initial withBlock:(id (^)(id accumulator, id object))block {
    id accumulator = initial;
    
    for (id object in self) {
        accumulator = accumulator ? block(accumulator, object) : object;
    }
    
    return accumulator;
}
@end
