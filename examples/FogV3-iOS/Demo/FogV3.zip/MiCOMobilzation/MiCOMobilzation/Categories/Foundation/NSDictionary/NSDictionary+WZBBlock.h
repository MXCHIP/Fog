//
//  NSDictionary+WZBBlock.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (WZBBlock)
- (void)wzb_each:(void (^)(id key, id value))block;
- (void)wzb_eachKey:(void (^)(id key))block;
- (void)wzb_eachValue:(void (^)(id value))block;

- (NSArray *)wzb_map:(id (^)(id key, id value))block;
- (NSDictionary *)wzb_pick:(NSArray *)keys;
- (NSDictionary *)wzb_omit:(NSArray *)keys;
@end
