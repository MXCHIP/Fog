//
//  NSString+WZBAdd.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (WZBAdd)
- (CGSize)wzb_sizeWithFont:(nullable UIFont *)font constrainedToWidth:(CGFloat)width;
//- (CGFloat)jk_widthWithFont:(UIFont *)font constrainedToHeight:(CGFloat)height;
- (nullable id)wzb_jsonValueDecoded;
@end
