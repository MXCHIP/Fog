//
//  NSData+WZBAdd.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/27.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSData+WZBAdd.h"

@implementation NSData (WZBAdd)
- (nullable id)wzb_jsonValueDecoded {
    NSError *error = nil;
    id value = [NSJSONSerialization JSONObjectWithData:self options:kNilOptions error:&error];
    if (error) {
        NSLog(@"jsonValueDecoded error:%@", error);
    }
    return value;
}
@end
