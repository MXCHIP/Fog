//
//  NSIndexPath+WZBOffset.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSIndexPath+WZBOffset.h"

@interface NSIndexPath ()
@end

@implementation NSIndexPath (WZBOffset)

- (NSIndexPath *)wzb_previousRow {
    return [NSIndexPath indexPathForRow:self.row - 1
                              inSection:self.section];
}

- (NSIndexPath *)wzb_nextRow {
    return [NSIndexPath indexPathForRow:self.row + 1
                              inSection:self.section];
}

- (NSIndexPath *)wzb_previousItem {
    return [NSIndexPath indexPathForItem:self.row - 1
                               inSection:self.section];
}

- (NSIndexPath *)wzb_nextItem {
    return [NSIndexPath indexPathForItem:self.row + 1
                               inSection:self.section];
}

- (NSIndexPath *)wzb_previousSection {
    return [NSIndexPath indexPathForRow:self.row
                              inSection:self.section - 1];
}

- (NSIndexPath *)wzb_nextSection {
    return [NSIndexPath indexPathForRow:self.row
                              inSection:self.section + 1];
}
@end
