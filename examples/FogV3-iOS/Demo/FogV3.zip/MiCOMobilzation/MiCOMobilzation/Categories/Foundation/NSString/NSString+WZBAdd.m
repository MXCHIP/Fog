//
//  NSString+WZBAdd.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSString+WZBAdd.h"
#import "NSData+WZBAdd.h"

@implementation NSString (WZBAdd)
- (CGSize)wzb_sizeWithFont:(UIFont *)font constrainedToWidth:(CGFloat)width {
    UIFont *textFont = font ? font : [UIFont systemFontOfSize:[UIFont systemFontSize]];
    
    CGSize textSize;
    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.lineBreakMode = NSLineBreakByWordWrapping;
    NSDictionary *attributes = @{NSFontAttributeName: textFont,
                                 NSParagraphStyleAttributeName: paragraph};
    textSize = [self boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX)
                                  options:(NSStringDrawingUsesLineFragmentOrigin |
                                           NSStringDrawingTruncatesLastVisibleLine)
                               attributes:attributes
                                  context:nil].size;
    
    return CGSizeMake(ceil(textSize.width), ceil(textSize.height));
}

- (nullable id)wzb_jsonValueDecoded {
    return [[self wzb_dataValue] wzb_jsonValueDecoded];
}

- (NSData *)wzb_dataValue {
    return [self dataUsingEncoding:NSUTF8StringEncoding];
}
@end
