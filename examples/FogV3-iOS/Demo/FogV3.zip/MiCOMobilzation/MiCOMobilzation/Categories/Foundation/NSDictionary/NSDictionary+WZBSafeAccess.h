//
//  NSDictionary+WZBSafeAccess.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSDictionary (WZBSafeAccess)
- (BOOL)wzb_hasKey:(NSString *)key;
- (NSString *)wzb_stringForKey:(id)key;
- (NSNumber *)wzb_numberForKey:(id)key;
- (NSDecimalNumber *)wzb_decimalNumberForKey:(id)key;
- (NSArray *)wzb_arrayForKey:(id)key;
- (NSDictionary *)wzb_dictionaryForKey:(id)key;
- (NSInteger)wzb_integerForKey:(id)key;
- (NSUInteger)wzb_unsignedIntegerForKey:(id)key;
- (BOOL)wzb_boolForKey:(id)key;
- (int16_t)wzb_int16ForKey:(id)key;
- (int32_t)wzb_int32ForKey:(id)key;
- (int64_t)wzb_int64ForKey:(id)key;
- (char)wzb_charForKey:(id)key;
- (short)wzb_shortForKey:(id)key;
- (float)wzb_floatForKey:(id)key;
- (double)wzb_doubleForKey:(id)key;
- (long long)wzb_longLongForKey:(id)key;
- (unsigned long long)wzb_unsignedLongLongForKey:(id)key;
- (NSDate *)wzb_dateForKey:(id)key dateFormat:(NSString *)dateFormat;
//CG
- (CGFloat)wzb_CGFloatForKey:(id)key;
- (CGPoint)wzb_pointForKey:(id)key;
- (CGSize)wzb_sizeForKey:(id)key;
- (CGRect)wzb_rectForKey:(id)key;
@end

@interface NSMutableDictionary (WZBSafeAccess)
- (void)wzb_setObject:(id)object forKey:(NSString *)key;
- (void)wzb_setString:(NSString *)string forKey:(NSString *)key;
- (void)wzb_setBool:(BOOL)i forKey:(NSString *)key;
- (void)wzb_setInt:(int)i forKey:(NSString *)key;
- (void)wzb_setInteger:(NSInteger)i forKey:(NSString *)key;
- (void)wzb_setUnsignedInteger:(NSUInteger)i forKey:(NSString *)key;
- (void)wzb_setCGFloat:(CGFloat)f forKey:(NSString *)key;
- (void)wzb_setFloat:(float)f forKey:(NSString *)key;
- (void)wzb_setChar:(char)c forKey:(NSString *)key;
- (void)wzb_setDouble:(double)d forKey:(NSString *)key;
- (void)wzb_setLongLong:(long long)i forKey:(NSString *)key;
- (void)wzb_setPoint:(CGPoint)point forKey:(NSString *)key;
- (void)wzb_setSize:(CGSize)size forKey:(NSString *)key;
- (void)wzb_setRect:(CGRect)rect forKey:(NSString *)key;
@end
