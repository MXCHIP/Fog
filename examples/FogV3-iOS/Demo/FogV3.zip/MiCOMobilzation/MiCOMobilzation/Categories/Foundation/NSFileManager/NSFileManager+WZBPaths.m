//
//  NSFileManager+WZBPaths.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/10.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "NSFileManager+WZBPaths.h"
#import <sys/xattr.h>

@implementation NSFileManager (WZBPaths)

+ (NSURL *)wzb_URLForDirectory:(NSSearchPathDirectory)directory {
    return [self.defaultManager URLsForDirectory:directory inDomains:NSUserDomainMask].lastObject;
}

+ (NSString *)wzb_pathForDirectory:(NSSearchPathDirectory)directory {
    return NSSearchPathForDirectoriesInDomains(directory, NSUserDomainMask, YES)[0];
}

+ (NSURL *)wzb_documentsURL {
    return [self wzb_URLForDirectory:NSDocumentDirectory];
}

+ (NSString *)wzb_documentsPath {
    return [self wzb_pathForDirectory:NSDocumentDirectory];
}

+ (NSURL *)wzb_libraryURL {
    return [self wzb_URLForDirectory:NSLibraryDirectory];
}

+ (NSString *)wzb_libraryPath {
    return [self wzb_pathForDirectory:NSLibraryDirectory];
}

+ (NSURL *)wzb_cachesURL {
    return [self wzb_URLForDirectory:NSCachesDirectory];
}

+ (NSString *)wzb_cachesPath {
    return [self wzb_pathForDirectory:NSCachesDirectory];
}

+ (double)wzb_availableDiskSpace {
    NSDictionary *attributes = [self.defaultManager attributesOfFileSystemForPath:self.wzb_documentsPath error:nil];
    
    return [attributes[NSFileSystemFreeSize] unsignedLongLongValue] / (double)0x100000;
}
@end
