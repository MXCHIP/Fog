//
//  UIButton+WZBBlock.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^WZBTouchedButtonBlock)(NSInteger tag);

@interface UIButton (WZBBlock)
- (void)wzb_addActionHandler:(WZBTouchedButtonBlock)touchHandler;
@end
