//
//  UIBarButtonItem+WZBAction.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIBarButtonItem+WZBAction.h"
#import <objc/runtime.h>
char * const UIBarButtonItemWZBActionBlock = "UIBarButtonItemWZBActionBlock";

@implementation UIBarButtonItem (WZBAction)

- (void)wzb_performActionBlock {
    dispatch_block_t block = self.wzb_actionBlock;
    if (block) {
        block();
    }
}

- (BarButtonWZBActionBlock)wzb_actionBlock {
    return objc_getAssociatedObject(self, UIBarButtonItemWZBActionBlock);
}

- (void)setWZB_ActionBlock:(BarButtonWZBActionBlock)actionBlock {
    if (actionBlock != self.wzb_actionBlock) {
        [self willChangeValueForKey:@"wzb_actionBlock"];
        
        objc_setAssociatedObject(self, UIBarButtonItemWZBActionBlock, actionBlock, OBJC_ASSOCIATION_COPY);
        [self setTarget:self];
        [self setAction:@selector(wzb_performActionBlock)];
        
        [self didChangeValueForKey:@"wzb_actionBlock"];
    }
}

@end
