//
//  UIButton+WZBBackgroundColor.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (WZBBackgroundColor)
- (void)wzb_setBackgroundColor:(UIColor *)color forState:(UIControlState)state;
@end
