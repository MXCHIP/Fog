//
//  UIColor+WZBAdd.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (WZBAdd)
+ (UIColor *)wzb_colorWithHex:(UInt32)hex;
+ (UIColor *)wzb_colorWithHex:(UInt32)hex andAlpha:(CGFloat)alpha;
+ (UIColor *)wzb_colorWithHexString:(NSString *)hexString;
- (NSString *)wzb_HEXString;
///值不需要除以255.0
+ (UIColor *)wzb_colorWithWholeRed:(CGFloat)red
                             green:(CGFloat)green
                              blue:(CGFloat)blue
                             alpha:(CGFloat)alpha;
///值不需要除以255.0
+ (UIColor *)wzb_colorWithWholeRed:(CGFloat)red
                             green:(CGFloat)green
                              blue:(CGFloat)blue;
@end
