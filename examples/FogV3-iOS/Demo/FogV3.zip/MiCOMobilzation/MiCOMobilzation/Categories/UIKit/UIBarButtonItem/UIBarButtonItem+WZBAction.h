//
//  UIBarButtonItem+WZBAction.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^BarButtonWZBActionBlock)();

@interface UIBarButtonItem (WZBAction)
- (void)setWZB_ActionBlock:(BarButtonWZBActionBlock)actionBlock;
@end
