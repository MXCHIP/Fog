//
//  UIButton+WZBBlock.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIButton+WZBBlock.h"
#import <objc/runtime.h>

static const void *wzb_UIButtonBlockKey = &wzb_UIButtonBlockKey;

@implementation UIButton (WZBBlock)
- (void)wzb_addActionHandler:(WZBTouchedButtonBlock)touchHandler {
    objc_setAssociatedObject(self, wzb_UIButtonBlockKey, touchHandler, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self addTarget:self action:@selector(wzb_blockActionTouched:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)wzb_blockActionTouched:(UIButton *)button {
    WZBTouchedButtonBlock block = objc_getAssociatedObject(self, wzb_UIButtonBlockKey);
    if (block) {
        block(button.tag);
    }
}
@end
