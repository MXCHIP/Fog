//
//  UIButton+WZBCountDown.h
//  EasyLinkDemoByWZB
//
//  Created by wuzhengbin on 2017/3/15.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (WZBCountDown)
- (void)wzb_startTime:(NSInteger)timeout title:(NSString *)title waitingTitle:(NSString *)waitingTitle;
@end
