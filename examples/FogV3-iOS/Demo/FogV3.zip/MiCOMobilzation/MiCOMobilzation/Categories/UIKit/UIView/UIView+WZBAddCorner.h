//
//  UIView+WZBAddCorner.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (WZBAddCorner)
- (void)wzb_addCustomCornerWithSize:(CGSize)size;
@end
