//
//  UIView+WZBFrame.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (WZBFrame)
@property (nonatomic, assign) CGPoint wzb_origin;
@property (nonatomic, assign) CGSize wzb_size;

@property (nonatomic) CGFloat wzb_centerX;
@property (nonatomic) CGFloat wzb_centerY;

@property (nonatomic) CGFloat wzb_top;
@property (nonatomic) CGFloat wzb_bottom;
@property (nonatomic) CGFloat wzb_right;
@property (nonatomic) CGFloat wzb_left;

@property (nonatomic) CGFloat wzb_width;
@property (nonatomic) CGFloat wzb_height;

@end
