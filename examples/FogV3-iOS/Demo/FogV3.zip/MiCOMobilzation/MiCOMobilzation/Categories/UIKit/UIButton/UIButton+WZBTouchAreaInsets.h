//
//  UIButton+WZBTouchAreaInsets.h
//  EasyLinkDemoByWZB
//
//  Created by wuzhengbin on 2017/3/15.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (WZBTouchAreaInsets)
@property (nonatomic, assign) UIEdgeInsets wzb_touchAreaInsets;
@end
