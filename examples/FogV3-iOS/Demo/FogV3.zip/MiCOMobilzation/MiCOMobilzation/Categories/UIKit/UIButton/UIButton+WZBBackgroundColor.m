//
//  UIButton+WZBBackgroundColor.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIButton+WZBBackgroundColor.h"

@implementation UIButton (WZBBackgroundColor)

+ (UIImage *)wzb_b_imageWithColor:(UIColor *)color {
    CGRect rect = CGRectMake(0.0, 0.0, 1.0, 1.0);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

- (void)wzb_setBackgroundColor:(UIColor *)color forState:(UIControlState)state {
    [self setBackgroundImage:[UIButton wzb_b_imageWithColor:color] forState:state];
}

@end
