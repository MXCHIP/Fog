//
//  UIImage+WZBAdd.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (WZBAdd)
- (UIImage *)wzb_imageByResizeToSize:(CGSize)size;
+ (UIImage *)wzb_imageWithColor:(UIColor *)color;
- (UIImage *)wzb_tintWithColor:(UIColor *)color;
@end
