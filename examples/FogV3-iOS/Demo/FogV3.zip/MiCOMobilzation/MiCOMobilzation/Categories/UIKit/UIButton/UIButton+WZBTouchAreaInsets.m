//
//  UIButton+WZBTouchAreaInsets.m
//  EasyLinkDemoByWZB
//
//  Created by wuzhengbin on 2017/3/15.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIButton+WZBTouchAreaInsets.h"
#import <objc/runtime.h>

@implementation UIButton (WZBTouchAreaInsets)

- (UIEdgeInsets)wzb_touchAreaInsets {
    return [objc_getAssociatedObject(self, @selector(wzb_touchAreaInsets)) UIEdgeInsetsValue];
}

- (void)setWzb_touchAreaInsets:(UIEdgeInsets)touchAreaInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:touchAreaInsets];
    objc_setAssociatedObject(self, @selector(wzb_touchAreaInsets), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    UIEdgeInsets touchAreaInsets = self.wzb_touchAreaInsets;
    CGRect bounds = self.bounds;
    bounds = CGRectMake(bounds.origin.x - touchAreaInsets.left,
                        bounds.origin.y - touchAreaInsets.top,
                        bounds.size.width + touchAreaInsets.left + touchAreaInsets.right,
                        bounds.size.height + touchAreaInsets.top + touchAreaInsets.bottom);
    return CGRectContainsPoint(bounds, point);
}

@end
