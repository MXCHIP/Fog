//
//  UIView+WZBFrame.m
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIView+WZBFrame.h"

@implementation UIView (WZBFrame)

- (CGFloat)wzb_top {
    return self.frame.origin.y;
}

- (void)setWzb_top:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)wzb_right {
    return self.frame.size.width + self.frame.origin.x;
}

- (void)setWzb_right:(CGFloat)right {
    CGRect frame = self.frame;
    frame.origin.x = right - self.frame.size.width;
    self.frame = frame;
}

- (CGFloat)wzb_bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setWzb_bottom:(CGFloat)bottom {
    CGRect frame = self.frame;
    frame.origin.y = bottom - self.frame.size.height;
    self.frame = frame;
}

- (CGFloat)wzb_left {
    return self.frame.origin.x;
}

- (void)setWzb_left:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)wzb_width {
    return self.frame.size.width;
}

- (void)setWzb_width:(CGFloat)width {
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)wzb_height {
    return self.frame.size.height;
}

- (void)setWzb_height:(CGFloat)height {
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGPoint)wzb_origin {
    return self.frame.origin;
}

- (void)setWzb_origin:(CGPoint)origin {
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGSize)wzb_size {
    return self.frame.size;
}

- (void)setWzb_size:(CGSize)size {
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

- (CGFloat)wzb_centerX {
    return self.center.x;
}

- (void)setWzb_centerX:(CGFloat)centerX {
    self.center = CGPointMake(centerX, self.center.y);
}

- (CGFloat)wzb_centerY {
    return self.center.y;
}

- (void)setWzb_centerY:(CGFloat)centerY {
    self.center = CGPointMake(self.center.x, centerY);
}
@end
