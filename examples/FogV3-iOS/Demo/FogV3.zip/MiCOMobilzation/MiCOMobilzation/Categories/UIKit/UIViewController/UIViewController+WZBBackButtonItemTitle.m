//
//  UIViewController+WZBBackButtonItemTitle.m
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import "UIViewController+WZBBackButtonItemTitle.h"

@implementation UIViewController (WZBBackButtonItemTitle)

@end

@implementation UINavigationController (WZBNavigationItemBackButtonTitle)

- (BOOL)navigationBar:(UINavigationBar *)navigationBar shouldPushItem:(UINavigationItem *)item {
    
    UIViewController *vc = self.viewControllers.count > 1 ? [self.viewControllers objectAtIndex:self.viewControllers.count - 2] : nil;
    if (!vc) {
        return YES;
    }
    
    NSString *backButtonTitle = nil;
    if ([vc respondsToSelector:@selector(wzb_navigationItemBackBarButtonTitle)]) {
        backButtonTitle  = [vc wzb_navigationItemBackBarButtonTitle];
    }
    
    if (!backButtonTitle) {
        backButtonTitle = vc.title;
    }
    
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithTitle:backButtonTitle style:UIBarButtonItemStylePlain target:nil action:nil];
    vc.navigationItem.backBarButtonItem = backButtonItem;
    
    return YES;
}

@end
