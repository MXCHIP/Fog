//
//  UIViewController+WZBBackButtonItemTitle.h
//  WZBCategories
//
//  Created by wuzhengbin on 2017/3/13.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol WZBBackButtonItemTitleProtocol <NSObject>
@optional
- (NSString *)wzb_navigationItemBackBarButtonTitle;
@end

@interface UIViewController (WZBBackButtonItemTitle) <WZBBackButtonItemTitleProtocol>

@end
