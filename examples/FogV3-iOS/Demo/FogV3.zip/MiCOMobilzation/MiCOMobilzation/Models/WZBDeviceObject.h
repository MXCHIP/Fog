//
//  WZBDeviceObject.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/16.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJExtension.h"

/**
 {
     "device_id" = "47fa3c3c-089f-11e7-9baf-00163e120d98";
     "device_name" = "micokit-XXX";
     "device_pw" = 4862;
     gatewaytype = 0;
     "is_sub" = 0;
     mac = D0BAE418726C;
     online = 1;
     parentid = "<null>";
     "product_icon" = "";
     "product_name" = "micokit-XXX";
     role = 1;
 }
 
 */

@interface WZBDeviceObject : NSObject
@property(nonatomic, copy) NSString *device_id;
@property(nonatomic, copy) NSString *device_name;
@property(nonatomic, copy) NSString *device_pw;
@property(nonatomic, copy) NSString *mac;
@property(nonatomic, assign) BOOL online;
@property(nonatomic, assign) NSInteger role;


@property (nonatomic ,strong) NSString *product_name;

@property (nonatomic ,assign) NSInteger gatewaytype;

@property (nonatomic ,strong) NSString *product_icon;

@property (nonatomic ,strong) NSString *product_id;
@end
