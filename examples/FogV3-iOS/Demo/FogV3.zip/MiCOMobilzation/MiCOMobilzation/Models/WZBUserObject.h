//
//  WZBUserObject.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/17.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJExtension.h"
/**
 data =     {
     app = "7e05d7d6-f987-11e6-9d95-00163e103941";
     avatar = "";
     city = "";
     "date_joined" = "2017-03-07T11:00:00.340665";
     email = "";
     emailverified = 0;
     lf = "274e63fe-02e2-11e7-9d95-00163e103941";
     gender = "";
     "is_active" = 1;
     "is_virtual" = 0;
     "last_login" = "2017-03-17T11:10:37.587041";
     nickname = "";
     note = "";
     phone = 13761768696;
     phonearea = "+86";
     phoneverified = 1;
     realname = "";
 };
 meta =     {
     code = 0;
     message = "success to user info";
 };
 
 */

@interface WZBUserObject : NSObject <NSCoding>
@property (nonatomic, copy) NSString *app;
@property (nonatomic, copy) NSString *avatar;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *date_joined;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, assign) BOOL emailverified;
@property (nonatomic, copy) NSString *enduserid;
@property (nonatomic, assign) NSInteger gender;
@property (nonatomic, assign) NSInteger is_active;
@property (nonatomic, copy) NSString *phone;
@property (nonatomic, copy) NSString *phonearea;
@property (nonatomic, copy) NSString *realname;
@end
