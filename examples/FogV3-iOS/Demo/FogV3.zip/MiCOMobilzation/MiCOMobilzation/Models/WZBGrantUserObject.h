//
//  WZBGrantUserObject.h
//  MiCOMobilzation
//
//  Created by wuzhengbin on 2017/3/27.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WZBGrantUserObject : NSObject
@property (nonatomic , copy) NSString *phone;
@property (nonatomic , copy) NSString *appid;
@property (nonatomic , copy) NSString *nickname;
@property (nonatomic , copy) NSString *enduserid;
@property (nonatomic , copy) NSString *role;
@property (nonatomic , copy) NSString *email;
@property (nonatomic , copy) NSString *realname;
@property (nonatomic , assign) BOOL is_active;
@end
