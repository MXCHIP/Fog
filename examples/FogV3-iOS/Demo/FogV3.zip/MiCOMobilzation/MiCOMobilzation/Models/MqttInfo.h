//
//  MqttInfo.h
//  MiCOMobilzation
//
//  Created by 黄坚 on 2017/8/1.
//  Copyright © 2017年 wuzhengbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MqttInfo : NSObject
@property (nonatomic ,strong) NSString *password;

@property (nonatomic ,strong) NSString *endpoint;

@property (nonatomic ,assign) NSInteger mqttport;

@property (nonatomic ,strong) NSString *loginname;

@property (nonatomic ,strong) NSString *clientid;

@property (nonatomic ,strong) NSString *mqtthost;

@end
