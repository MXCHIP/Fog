package com.mxchip.easylink;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mxchip.api.EasyLink;
import com.mxchip.helper.EasyLinkCallBack;
import com.mxchip.helper.EasyLinkParams;
import com.mxchip.wifiman.EasyLinkWifiManager;

/**
 * 
 * @author Rocke
 * 
 */
public class MainActivity extends Activity {
	private String TAG = "---ey 2.0 ";

	private Button startsearch;
	private Button stopsearch;
	private EditText wifissid;
	private EditText wifipsw;
	private EditText sleeptime;
	private TextView logmessage;

	public EasyLink elapi;
	private Context ctx = null;
	private EasyLinkWifiManager mWifiManager = null;

	private MyHandler myhandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		wifissid = (EditText) findViewById(R.id.wifissid);
		wifipsw = (EditText) findViewById(R.id.wifipsw);
		startsearch = (Button) findViewById(R.id.startsearch);
		stopsearch = (Button) findViewById(R.id.stopsearch);
		logmessage = (TextView) findViewById(R.id.logmessage);
		sleeptime = (EditText) findViewById(R.id.sleeptime);

		ctx = MainActivity.this;
		elapi = new EasyLink();

		mWifiManager = new EasyLinkWifiManager(ctx);
		wifissid.setText(mWifiManager.getCurrentSSID());

		myhandler = new MyHandler();

		startsearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String sltStr = sleeptime.getText().toString().trim();
				int sleeptime = Integer.parseInt(sltStr);

				EasyLinkParams easylinkPara = new EasyLinkParams();
				easylinkPara.ssid = wifissid.getText().toString().trim();
				easylinkPara.password = wifipsw.getText().toString().trim();
				easylinkPara.runSecond = 20000;
				easylinkPara.sleeptime = sleeptime;
				easylinkPara.extraData = "tom";
				// easylinkPara.rc4key = "";

				elapi.startEasyLink(ctx, easylinkPara, new EasyLinkCallBack() {

					@Override
					public void onSuccess(int code, String message) {
						Log.d(TAG, code + message);

						Message msg = new Message();
						msg.what = 1;
						msg.obj = "code =  " + code + ", message = " + message;
						myhandler.sendMessage(msg);
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, code + message);
						Message msg = new Message();
						msg.what = 1;
						msg.obj = "code =  " + code + ", message = " + message;
						myhandler.sendMessage(msg);
					}
				});
			}
		});

		stopsearch.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				elapi.stopEasyLink(new EasyLinkCallBack() {

					@Override
					public void onSuccess(int code, String message) {
						Log.d(TAG, code + message);
						Message msg = new Message();
						msg.what = 1;
						msg.obj = "code =  " + code + ", message = " + message;
						myhandler.sendMessage(msg);
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, code + message);
						Message msg = new Message();
						msg.what = 1;
						msg.obj = "code =  " + code + ", message = " + message;
						myhandler.sendMessage(msg);
					}
				});
			}
		});
	}

	class MyHandler extends Handler {

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			logmessage.setText(msg.obj.toString());
		}
	}
}
