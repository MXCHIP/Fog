package com.mxchip.serviceactivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mxchip.helper.ListenDeviceCallBack;
import com.mxchip.helper.ListenDeviceParams;
import com.mxchip.mqttservice2.MQTT;

public class MainActivity extends Activity implements OnClickListener {
	String LOG_TAG = "---activity---";

	private Button startmqtt, stopmqtt, publish, addsubscrib, unsubscrib;
	private TextView logview;

	private MQTT mqttapi;

	private Context ctx;

	String txtin = null;
	private MyHandler myhandler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ctx = MainActivity.this;
		mqttapi = new MQTT(ctx);
		myhandler = new MyHandler();

		initView();
		initClick();
	}

	private LinearLayout configll;
	private EditText hostet;
	private EditText portet;
	private EditText userNameet;
	private EditText passWordet;
	private EditText topicet;
	private EditText clientIDet;
	private EditText addtopicet;
	private EditText sendtopicet;
	private EditText commandet;

	private void initView() {
		startmqtt = (Button) findViewById(R.id.startmqtt);
		stopmqtt = (Button) findViewById(R.id.stopmqtt);
		publish = (Button) findViewById(R.id.publish);
		addsubscrib = (Button) findViewById(R.id.addsubscrib);
		unsubscrib = (Button) findViewById(R.id.unsubscrib);
		logview = (TextView) findViewById(R.id.logview);

		configll = (LinearLayout) findViewById(R.id.configll);

		hostet = (EditText) findViewById(R.id.hostet);
		portet = (EditText) findViewById(R.id.portet);
		userNameet = (EditText) findViewById(R.id.userNameet);
		passWordet = (EditText) findViewById(R.id.passWordet);
		clientIDet = (EditText) findViewById(R.id.clientIDet);
		topicet = (EditText) findViewById(R.id.topicet);
		addtopicet = (EditText) findViewById(R.id.addtopicet);
		sendtopicet = (EditText) findViewById(R.id.sendtopicet);
		commandet = (EditText) findViewById(R.id.commandet);
	}

	private void initClick() {
		startmqtt.setOnClickListener(this);
		stopmqtt.setOnClickListener(this);
		publish.setOnClickListener(this);
		addsubscrib.setOnClickListener(this);
		unsubscrib.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.startmqtt:

			ListenDeviceParams ldp = new ListenDeviceParams();
			ldp.host = hostet.getText().toString().trim();
			ldp.port = portet.getText().toString().trim();
			ldp.userName = userNameet.getText().toString().trim();
			ldp.passWord = passWordet.getText().toString().trim();
			ldp.topic = topicet.getText().toString().trim();
			ldp.clientID = clientIDet.getText().toString().trim();

			mqttapi.startListenDevice(ldp, new ListenDeviceCallBack() {
				@Override
				public void onSuccess(String message) {
					Log.d("---", message);
					configll.setVisibility(View.GONE);
					sendMSGH(message);
				}

				@Override
				public void onFailure(int code, String message) {
					Log.d("---", code + " - " + message);
					sendMSGH(code + " - " + message);
				}

				@Override
				public void onDeviceStatusReceived(int code, String messages) {
					Log.d("---" + code + "---", messages);
					sendMSGH(code + messages);
				}
			});
			break;
		case R.id.stopmqtt:
			mqttapi.stopListenDevice(new ListenDeviceCallBack() {
				@Override
				public void onSuccess(String message) {
					Log.d("---", message);
					configll.setVisibility(View.VISIBLE);
					sendMSGH(message);
				}

				@Override
				public void onFailure(int code, String message) {
					Log.d("---", code + " - " + message);
					sendMSGH(code + " - " + message);
				}
			});
			break;
		case R.id.publish:
			String sendtopic = sendtopicet.getText().toString().trim();
			String command = commandet.getText().toString().trim();
			mqttapi.sendCommand(sendtopic, command, 0, false,
					new ListenDeviceCallBack() {
						@Override
						public void onSuccess(String message) {
							Log.d("---", message);
							sendMSGH(message);
						}

						@Override
						public void onFailure(int code, String message) {
							Log.d("---", code + " - " + message);
							sendMSGH(code + " - " + message);
						}
					});
			break;
		case R.id.addsubscrib:
			String addtopic = addtopicet.getText().toString().trim();
			mqttapi.addDeviceListener(addtopic, 0, new ListenDeviceCallBack() {
				@Override
				public void onSuccess(String message) {
					Log.d("---", message);
					sendMSGH(message);
				}

				@Override
				public void onFailure(int code, String message) {
					Log.d("---", code + " - " + message);
					sendMSGH(code + " - " + message);
				}
			});
			break;
		case R.id.unsubscrib:
			String rmtopic = addtopicet.getText().toString().trim();
			mqttapi.removeDeviceListener(rmtopic, new ListenDeviceCallBack() {
				@Override
				public void onSuccess(String message) {
					Log.d("---", message);
					sendMSGH(message);
				}

				@Override
				public void onFailure(int code, String message) {
					Log.d("---", code + " - " + message);
					sendMSGH(code + " - " + message);
				}
			});
			break;
		}
	}

	private void sendMSGH(String message) {
		Message msg = new Message();
		msg.what = 1;
		msg.obj = message;
		myhandler.sendMessage(msg);
	}

	class MyHandler extends Handler {
		int count = 0;

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(count > 10){
				logview.setText("");
				count = 0;
			}
			logview.append(msg.obj.toString() + "\r\n");
			count ++;
		}
	}
}
