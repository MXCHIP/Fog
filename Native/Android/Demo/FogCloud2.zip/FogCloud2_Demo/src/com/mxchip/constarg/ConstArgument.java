package com.mxchip.constarg;

/**
 * 常用的接口和参数 项目名称：FogCloud2Demo 创建人：Sin 创建时间：2016年1月18日 下午4:52:23
 * 
 * @version 1.0
 */
public class ConstArgument {
	
	/**
	 * APP在云端注册后得到的APPID的值
	 */
    public static String _APPID = "d8cdf9c6-de8c-11e5-a739-00163e0204c0";
//	public static String _APPID = "81d79316-bb5a-11e5-a739-00163e0204c0";

	public static String _PRODUCTID = "6486b2d1-0ee9-4647-baa3-78b9cbc778f7";
	public static String _DEVMAC = "d0bae40c2fee";

    /**
     * device ID
     */
    public static String DEVICEID = "d95366fe-06c0-11e6-a739-00163e0204c0";
	
	/**
	 * device password
	 */
	public static String DEVICEPW = "123456";
//	public static String DEVICEPW = "9298";
	
	/**
	 * 绑定设备时候，设备去云端申请绑定得到的vercode，10分钟有效
	 */
	public static String DEVVERCODE = "c9e471c2-bb66-11e5-a739-00163e0204c0";
	
	/**
	 * 分享用户的权限 2：管理员 3：普通用户
	 */
	public static int ROLE = 2;

	/**
	 * 绑定类型
	 */
	public static String BINDINGTYPE = "sa";
}
