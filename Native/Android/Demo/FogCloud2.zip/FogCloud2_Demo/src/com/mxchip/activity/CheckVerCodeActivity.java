package com.mxchip.activity;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.mico.micosdk.MiCOUser;
import com.mxchip.callbacks.UserCallBack;
import com.mxchip.constarg.ConstArgument;
import com.mxchip.constarg.FogHelp;

/**
 * 获取验证码，并验证验证码 
 * 项目名称：FogCloud2Demo 
 * 创建人：Sin 
 * 创建时间：2016年1月18日 下午4:42:17
 * 
 * @version 1.0
 */
public class CheckVerCodeActivity extends Activity {

	private EditText ckUserName;
	private EditText ckVerCode;
	private Button ckCKVerCode;
	private Button getVercode;

	private String _APPID = ConstArgument._APPID;
	private MiCOUser micoUser = new MiCOUser();
	private String TAG = "---CheckVerCodeActivity---";

	private FogHelp fh;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.checkcode);

		initView();
		fh = new FogHelp();
		initOnClick();
	}

	private void initView() {
		ckUserName = (EditText) findViewById(R.id.ckUserName);
		ckVerCode = (EditText) findViewById(R.id.ckVerCode);
		getVercode = (Button) findViewById(R.id.getVercode);
		ckCKVerCode = (Button) findViewById(R.id.ckCKVerCode);
	}

	private void initOnClick() {
		/**
		 * 获取手机验证码
		 */
		getVercode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String userName = ckUserName.getText().toString();
				if (fh.checkPara(userName)) {
					micoUser.getVerifyCode(userName, _APPID, new UserCallBack() {

						@Override
						public void onSuccess(String message) {
							Log.d(TAG, message.toString());
							fh.setToast(CheckVerCodeActivity.this,
									message.toString());
						}

						@Override
						public void onFailure(int code, String message) {
							Log.d(TAG, message.toString());
							fh.setToast(CheckVerCodeActivity.this,
									message.toString());
						}
					});
				} else {
					fh.setToast(CheckVerCodeActivity.this, "参数为空");
				}
			}
		});
		/**
		 * 验证手机验证码
		 */
		ckCKVerCode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final String userName = ckUserName.getText().toString();
				final String vercode = ckVerCode.getText().toString();
				if (fh.checkPara(userName, vercode)) {
					micoUser.checkVerifyCode(userName, vercode, _APPID,
							new UserCallBack() {

								@Override
								public void onSuccess(String message) {
									Log.d(TAG, message);
									
									try {
										String token = new JSONObject(message).getString("token");
										// 跳转去注册界面并把username传递过去
										Intent intent = new Intent( CheckVerCodeActivity.this, RegisterActivity.class);
										intent.putExtra("token", token);
										startActivity(intent);
									} catch (JSONException e) {
										e.printStackTrace();
									}
								}

								@Override
								public void onFailure(int code, String message) {
									Log.d(TAG, message);
									fh.setToast(CheckVerCodeActivity.this, message);
								}
							});
				} else {
					fh.setToast(CheckVerCodeActivity.this, "参数为空");
				}
			}
		});
	}

}
