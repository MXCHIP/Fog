package com.mxchip.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.mico.micosdk.MiCOUser;
import com.mxchip.callbacks.UserCallBack;
import com.mxchip.constarg.FogHelp;

/**
 * 登录成功后的首页 
 * 项目名称：FogCloud2Demo 
 * 创建人：Sin 
 * 创建时间：2016年1月18日 下午4:57:56
 * 
 * @version 1.0
 */
public class HomePageActivity extends Activity {

	private Button reFreshJwt;
	private Button checkJwt;
	private Button addDevice;
	private Button toQRCodePage;
	private TextView checkMessage;
	private TextView manageUser;

	private SharedPreferences sharedPreferences;
	private MiCOUser fcapi = new MiCOUser();
	private String TAG = "---HomePageActivity---";

	private String userToken;
	private FogHelp fh;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.homepage);

		initView();
		initOnclick();

		sharedPreferences = getSharedPreferences("fogcloud",
				Activity.MODE_PRIVATE);
		// 获取localstorege里面的token
		userToken = sharedPreferences.getString("token", "");
		fh = new FogHelp();
	}

	private void initView() {
		reFreshJwt = (Button) findViewById(R.id.reFreshJwt);
		checkJwt = (Button) findViewById(R.id.checkJwt);
		toQRCodePage = (Button) findViewById(R.id.toQRCodePage);
		addDevice = (Button) findViewById(R.id.addDevice);
		checkMessage = (TextView) findViewById(R.id.checkMessage);
		manageUser = (TextView) findViewById(R.id.manageUser);
	}

	private void initOnclick() {
		/**
		 * 刷新token，服务器端默认生效时间为7天，每次打开APP后执行此接口，则在服务器端延后7天
		 */
		reFreshJwt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (fh.checkPara(userToken)) {
					fcapi.refreshToken(userToken, new UserCallBack() {

						@Override
						public void onSuccess(String message) {
							Log.d(TAG, message.toString());
							checkMessage.setText(message);
						}

						@Override
						public void onFailure(int code, String message) {
							Log.d(TAG, code + " " + message);
							checkMessage.setText(message);
						}
					});
				} else {
					checkMessage.setText("未获取到token，请重新登录");
				}
			}
		});
		/**
		 * 验证token
		 */
		checkJwt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (fh.checkPara(userToken)) {
					fcapi.verifyToken(userToken, new UserCallBack() {

						@Override
						public void onSuccess(String message) {
							Log.d(TAG, message);
							checkMessage.setText(message);
						}

						@Override
						public void onFailure(int code, String message) {
							Log.d(TAG, code + " " + message);
							checkMessage.setText(message);
						}
					});
				} else {
					checkMessage.setText("未获取到token，请重新登录");
				}
			}
		});
		// 通过二维码分享设备
		toQRCodePage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomePageActivity.this, QrCodeActivity.class);
				startActivity(intent);
			}
		});
		// 通过EasyLink配网，添加设备
		addDevice.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomePageActivity.this,
						EasyLinkActivity.class);
				startActivity(intent);
			}
		});
		// 去管理用户了
		manageUser.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(HomePageActivity.this, ManageUserActivity.class);
				startActivity(intent);
			}
		});
	}
}
