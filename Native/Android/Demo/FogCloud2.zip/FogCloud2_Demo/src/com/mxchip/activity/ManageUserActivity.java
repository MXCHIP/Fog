package com.mxchip.activity;

import com.mico.micosdk.MiCOUser;
import com.mxchip.callbacks.UserCallBack;
import com.mxchip.constarg.ConstArgument;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class ManageUserActivity extends Activity {
	
	private String TAG = "---ManageUserActivity---";
	
	private String deviceid = ConstArgument.DEVICEID;

	private EditText enduserid;
	private RadioGroup userchecked;
	private Button updateRole;
	private Button transferAdmin;
	private Button removeUser;
	private TextView managerlog;

	private String role = "3";
	private String userid = null;
	
	private MiCOUser micoUser = new MiCOUser();
	private SharedPreferences sharedPreferences;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.manageuser);
		
		sharedPreferences = getSharedPreferences("fogcloud", Activity.MODE_PRIVATE);

		initView();
		initOnclick();
	}

	private void initView() {
		enduserid = (EditText) findViewById(R.id.enduserid);
		userchecked = (RadioGroup) findViewById(R.id.userchecked);
		updateRole = (Button) findViewById(R.id.updateRole);
		transferAdmin = (Button) findViewById(R.id.transferAdmin);
		removeUser = (Button) findViewById(R.id.removeUser);
		managerlog = (TextView) findViewById(R.id.managerlog);
	}

	private void initOnclick() {
		final String jwttoken = sharedPreferences.getString("token", "");
		updateRole.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				userid = enduserid.getText().toString().trim();
				Log.d(TAG, userid + " " + role);
				micoUser.updateBindRole(deviceid, userid, role, new UserCallBack() {
					
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, message);
						managerlog.setText(message);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, code + " " +message);
						managerlog.setText(code + " " +message);
					}
				},jwttoken);
			}
		});
		transferAdmin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				userid = enduserid.getText().toString().trim();
				Log.d(TAG, userid + " " + role);
				micoUser.transferAminUser(deviceid, userid, new UserCallBack() {
					
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, message);
						managerlog.setText(message);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, code + " " +message);
						managerlog.setText(code + " " +message);
					}
				},jwttoken);
			}
		});
		removeUser.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				userid = enduserid.getText().toString().trim();
				Log.d(TAG, userid + " " + role);
				micoUser.removeBindRole(deviceid, userid, new UserCallBack() {
					
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, message);
						managerlog.setText(message);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, code + " " +message);
						managerlog.setText(code + " " +message);
					}
				}, jwttoken);
			}
		});
		userchecked.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				switch (checkedId) {
				case R.id.commonuser:
					role = "3";
					break;
				case R.id.manuser:
					role = "2";
					break;
				case R.id.adminuser:
					role = "1";
					break;
				}
			}
		});
	}
}
