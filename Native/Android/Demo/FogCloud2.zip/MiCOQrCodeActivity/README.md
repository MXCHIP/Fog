#QrCodeActivity
