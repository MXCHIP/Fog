package com.dtr.zxing.bean;

/**
 * code for handle
 * @author Rocke
 *
 */
public class ComminuteCode {
	public static final int PREVIEW = 886301;
	public static final int SUCCEEDED = 886302;
	public static final int FAILED = 886303;
	public static final int SCAN_RESULT = 886304;
	public static final int DECODE = 886305;
	public static final int QUITE = 886306;
	public static final int RESULT_CODE = 88630101;
}
